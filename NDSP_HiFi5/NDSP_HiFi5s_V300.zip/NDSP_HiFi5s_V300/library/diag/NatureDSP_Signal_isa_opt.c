/*
    NatureDSP_Signal library. Diagnostic routines.
    Discover hardware capabilities
    IntegrIT, 2006-2019
*/

/* Portable data types. */
#include "NatureDSP_types.h"
/* NatureDSP_Signal library diagnostic routines. */
#include "NatureDSP_Signal_diag.h"
/* Common utility declarations. */
#include "common.h"

/*-------------------------------------------------------------------------
Query of a particular ISA option or a parameter.
Input:
    isa_opt   ISA option or parameter identifier, one of NATUREDSP_ISA_OPT_
              symbols
Return value:
    Integral status value of the requested item, or -1 for an unknown value
    of the argument.
-------------------------------------------------------------------------*/
int NatureDSP_Signal_get_isa_opt( int isa_opt )
{
    switch (isa_opt) {
    case NATUREDSP_ISA_OPT_INT16_SIMD_WIDTH: return ((HIFI_SIMD_WIDTH)/sizeof(int16_t)); break;
    case NATUREDSP_ISA_OPT_HAVE_FP:          return (XCHAL_HAVE_FP                     ); break;
    case NATUREDSP_ISA_OPT_HAVE_DFP:         return (XCHAL_HAVE_DFP                    ); break;
    default: return (-1);
    }

} /* NatureDSP_Signal_get_isa_opt() */
