/*
  NatureDSP Signal Processing Library. FFT part
    Complex-valued FFT stages with butterflies radix-4, radix-8
    with static data scaling: 32-bit data, 16-bit twiddle factors
    C code optimized for HiFi4
  IntegrIT, 2006-2019
*/
#include "NatureDSP_types.h"
#include "common.h"
#include "fft_32x16_stages.h"
#include "fft_x16_common.h"

/*
 *  32x16 FFT/IFFT intermediate stage Radix 4, scalingOption=3
 *  Restriction: last stage must be radix 4
 */
int fft_32x16_stage_penultimate_scl3_DFT4x4(const int16_t *tw, const int32_t *x, int32_t *y, int N, int *v, int tw_step, int *bexp)
{
    return fft_32x16_stage_inner_scl3_DFT4x2(tw, x, y, N, v, tw_step, bexp);
} /* fft_32x16_stage_penultimate_scl3_DFT4x4 */
