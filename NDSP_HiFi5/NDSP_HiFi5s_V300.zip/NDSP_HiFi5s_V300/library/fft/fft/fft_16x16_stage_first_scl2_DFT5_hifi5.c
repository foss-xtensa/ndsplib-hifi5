/*
  NatureDSP Signal Processing Library. FFT part
    Complex-valued FFT stages with butterflies radix-2, radix-3, radix-5
    with static data scaling: 16-bit data, 16-bit twiddle factors
    C code optimized for HiFi5
  IntegrIT, 2006-2019
*/
#include "NatureDSP_types.h"
#include "common.h"
#include "fft_16x16_stages.h"

ALIGN(32) static const int16_t __dft5_tw[] =
{
    (int16_t)0x278E, (int16_t)0x278E, (int16_t)0x278E, (int16_t)0x278E,
    (int16_t)0x8644, (int16_t)0x79BC, (int16_t)0x8644, (int16_t)0x79BC,
    (int16_t)0x9872, (int16_t)0x9872, (int16_t)0x9872, (int16_t)0x9872,
    (int16_t)0xB4C3, (int16_t)0x4B3D, (int16_t)0xB4C3, (int16_t)0x4B3D
};

/* twiddles should be loaded from the table above
   requires setting bits 9:8,2:1 of SAR register to
   the scaling factor and bits 7,0 to zero!
*/
#define DFT5X2_SCALING(x0, x1, x2, x3, x4, w1, w2, w3, w4)\
{ \
    ae_int16x4 s1, s2, d1, d2;             \
    ae_int16x4 t0, t2;                     \
    ae_int16x4 y0, y1, y2, y3;             \
    t0=AE_ZERO16();                        \
    AE_ADDANDSUBRNG16RAS_S2(x0,t0);        \
    AE_ADDANDSUBRNG16RAS_S2(x1,x4);        \
    AE_ADDANDSUBRNG16RAS_S2(x2,x3);        \
    s1=x1;d1=x4; s2=x2; d2=x3;             \
    t0 = AE_MULFD16X16X4RAS(s1,s2, w1,w3); \
    t2 = AE_MULFD16X16X4RAS(s1,s2, w3,w1); \
    y0 = AE_ADD16S(x0, t0);                \
    y1 = AE_ADD16S(x0, t2);                \
    y2 = AE_MULFD16X16X4RAS(d1,d2, w2,w4); \
    y3 = AE_MULFD16X16X4RAS(d1,d2, w4,AE_NEG16S(w2)); \
    y2 = AE_SEL16_2301(y2, y2);           \
    y3 = AE_SEL16_2301(y3, y3);           \
    x0 = AE_ADD16S(x0, AE_ADD16S(s1, s2));\
    AE_ADDANDSUBRNG16RAS_S1(y0, y2);      \
    AE_ADDANDSUBRNG16RAS_S1(y1, y3);      \
    x1=y0; x4=y2; x2=y1; x3=y3;           \
}

/*
*  First stage of FFT 16x16, radix-5, dynamic scaling
*/
int fft_16x16_stage_first_scl2_DFT5(const int16_t *tw, const int16_t *x, int16_t *y, int N, int *v, int tw_step, int *bexp)
{
    /*  AE_SEL16_7632();
        AE_SEL16_5410();    */
    ALIGN(32) static const int16_t sel_tab[4] = {0x705,0x604,0x301,0x200};
    ae_int16x4 dsel=AE_L16X4_I((const ae_int16x4*)sel_tab,0);
    int i;
    const int N5=AE_MOVAD32_L(AE_MULFP32X2RAS(AE_MOVDA32(N),429496730));//N/5
    const int stride = N5;
    const int shift = XT_MAX(0,3 - *bexp);
    const ae_int16x4 * restrict px0;
    const ae_int16x4 * restrict px1;
    const ae_int16x4 * restrict px2;
    const ae_int16x4 * restrict px3;
    const ae_int16x4 * restrict px4;
    ae_int16x4 * restrict py0;
    const ae_int16x8 * restrict ptwd;
    const ae_int16x8 * restrict ptwd_dft;
    ae_int16x4 x0, x1, x2, x3, x4;
    ae_int16x4 w1, w2, w3, w4;
    NASSERT_ALIGN16(x);
    NASSERT_ALIGN16(y);
    NASSERT((stride & 1) == 0);

    px0 = (ae_int16x4 *)x;
    px1 = px0 + (stride>>1);
    px2 = px1 + (stride>>1);
    px3 = px2 + (stride>>1);
    px4 = px3 + (stride>>1);
    py0 = (ae_int16x4 *)y;
    ptwd = (const ae_int16x8 *)tw;
    ptwd_dft = (const ae_int16x8 *)__dft5_tw;
    AE_L16X4X2_IP(w1, w2,ptwd_dft, sizeof(ae_int16x8));
    AE_L16X4X2_IP(w3, w4,ptwd_dft, sizeof(ae_int16x8));
      /* Reset RANGE register */
    { int a, b;AE_CALCRNG16(a, b, 0, 3);(void)b; (void)a;  }
    WUR_AE_SAR(shift*0x102);
    __Pragma("loop_count min=2");
    for (i = 0; i <(stride >> 1); i++)
    {
        ae_int16x4 y0,y1,y2,y3,y4;
        ae_int16x4 tw1,tw2,tw3,tw4;
        AE_L16X4_IP(x0, px0, sizeof(ae_int16x4));
        AE_L16X4_IP(x1, px1, sizeof(ae_int16x4));
        AE_L16X4_IP(x2, px2, sizeof(ae_int16x4));
        AE_L16X4_IP(x3, px3, sizeof(ae_int16x4));
        AE_L16X4_IP(x4, px4, sizeof(ae_int16x4));
        DFT5X2_SCALING(x0, x1, x2, x3, x4, w1, w2, w3, w4);
        /* Load and unpack twiddles */
        AE_L16X4X2_IP(tw1, tw3, ptwd, sizeof(ae_int16x8));
        AE_L16X4X2_IP(tw2, tw4, ptwd, sizeof(ae_int16x8));
        AE_DSEL16X4(tw1,tw2,tw1,tw2,dsel);
        AE_DSEL16X4(tw3,tw4,tw3,tw4,dsel);
        y0=x0;
        y1 = AE_MULFC16RAS(x1, tw1);
        y2 = AE_MULFC16RAS(x2, tw2);
        y3 = AE_MULFC16RAS(x3, tw3);
        y4 = AE_MULFC16RAS(x4, tw4);
        // save with permutation
        AE_S16X4RNG_IP(AE_SEL16_7632(y0,y1), py0, sizeof(ae_int16x4));
        AE_S16X4RNG_IP(AE_SEL16_7632(y2,y3), py0, sizeof(ae_int16x4));
        AE_S16X4RNG_IP(AE_SEL16_7610(y4,y0), py0, sizeof(ae_int16x4));
        AE_S16X4RNG_IP(AE_SEL16_5410(y1,y2), py0, sizeof(ae_int16x4));
        AE_S16X4RNG_IP(AE_SEL16_5410(y3,y4), py0, sizeof(ae_int16x4));
    }
    // update block exponent
    {   int a, b; AE_CALCRNG16(a, b, 0, 3); *bexp = 3 - a; (void)b; }
    *v *= 5;
    return shift;
} /* fft_16x16_stage_first_scl2_DFT5() */
