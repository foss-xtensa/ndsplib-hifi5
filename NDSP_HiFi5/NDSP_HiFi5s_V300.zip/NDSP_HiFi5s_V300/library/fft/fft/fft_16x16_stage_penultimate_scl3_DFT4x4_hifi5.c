/*
  NatureDSP Signal Processing Library. FFT part
    Complex-valued FFT stages with butterflies radix-4, radix-8
    with static data scaling: 16-bit data, 16-bit twiddle factors
    C code optimized for HiFi5
  IntegrIT, 2006-2019
*/
#include "NatureDSP_types.h"
#include "common.h"
#include "fft_16x16_stages.h"

/*
 *  Penultimate stage of FFT/IFFT 16x16, radix-4, static scaling
 *  Restriction: last stage must be radix 4
 */
int fft_16x16_stage_penultimate_scl3_DFT4x4(const int16_t *tw, const int16_t *x, int16_t *y, int N, int *v, int tw_step, int *bexp)
{
    return fft_16x16_stage_inner_scl3_DFT4x2(tw, x, y, N, v, tw_step, bexp); 
} /* fft_16x16_stage_penultimate_scl3_DFT4x4() */
