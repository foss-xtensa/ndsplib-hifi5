/*
  NatureDSP Signal Processing Library. FFT part
    Complex-valued FFT stages with butterflies radix-2, radix-3, radix-5
    with static data scaling: 32-bit data, 16-bit twiddle factors
    C code optimized for HiFi5
  IntegrIT, 2006-2019
*/

#if 0 /* not used in library for now */

#include "NatureDSP_types.h"
#include "common.h"
#include "fft_32x16_stages.h"

/*
 *  32x16 FFT first stage Radix 2, scalingOption=3
 */
int fft_32x16_stage_first_scl3_DFT2(const int16_t *tw, const int32_t *x, int32_t *y, int N, int *v, int tw_step, int *bexp)
{
  int i, shift;
  const ae_int32x2 * restrict px0;
  const ae_int32x2 * restrict px1;
        ae_int32x2 * restrict py0;
  const ae_int32   * restrict ptwd;
  const int R = 2; // stage radix
  const int stride = (N >> 1);

  NASSERT_ALIGN16(x);
  NASSERT_ALIGN16(y);
  shift = 2;
  WUR_AE_SAR(shift);
  px0 = (ae_int32x2 *)x;
  px1 = (ae_int32x2 *)x + stride;
  py0 = (ae_int32x2 *)y;
  ptwd = (const ae_int32 *)tw;
  __Pragma("loop_count min=1");
  for (i = 0; i < stride; i++)
  {
    ae_int32x2 x0, x1, y0, y1;
    ae_int16x4 tw1;
    ae_int32x2 tw1_tmp;

    AE_L32_IP(tw1_tmp, ptwd, 2*sizeof(int16_t));
    tw1 = AE_SHORTSWAP(AE_MOVINT16X4_FROMINT32X2(tw1_tmp));

    AE_L32X2_IP(x0, px0, sizeof(ae_int32x2));
    AE_L32X2_IP(x1, px1, sizeof(ae_int32x2));

    AE_ADDANDSUBRNG32(y0, y1, x0, x1);
    y1 = AE_MULFC32X16RAS_L(y1, tw1);

    AE_S32X2_IP(y0, py0, sizeof(ae_int32x2));
    AE_S32X2_IP(y1, py0, sizeof(ae_int32x2));
  }
  *v *= R;
  return shift;
} /* fft_32x16_first_stage_scl3_DFT2() */
#endif
