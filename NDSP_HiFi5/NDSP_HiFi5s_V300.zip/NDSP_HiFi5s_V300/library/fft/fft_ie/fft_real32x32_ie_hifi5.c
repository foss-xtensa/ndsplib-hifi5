/*
    NatureDSP Signal Processing Library. FFT part
    C code optimized for HiFi4
    Integrit, 2006-2019
*/

/* Portable data types. */
#include "NatureDSP_types.h"
/* Signal Processing Library API. */
#include "NatureDSP_Signal_fft.h"
#include "NatureDSP_Signal_vector.h"
/* Common utility and macros declarations. */
#include "common.h"
#define _CONJ32(_x) {_x = AE_SEL32_HL(_x, AE_NEG32S(_x) ); }

/*----------------------------------------------------------------------------
Apply the in-place real-to-complex spectrum conversion
MATLAB code:
twd = exp(-2*pi*1j*(0:N/4-1)/N);
a0 = y(1:N/4);
a1 = [y(1),wrev(y(N/4+2:N/2))];
b0 = 1/2*(a0+conj(a1));
b1 = 1/2*(a0-conj(a1))*-1j.*twd;
a0 = b0+b1;
a1 = b0-b1;
y(1:N) = [a0,conj(y(N/4+1)),wrev(conj(a1(2:N/4))), ...
a1,     y(N/4+1) ,wrev(conj(a0(2:N/4)))];
*/
static int SpectrConv(complex_fract32 *y, int N, const complex_fract32 *twiddle_table, int twiddle_stride, int scalingOpt, int bexp)
{
    ae_int32x2 vA0, vA1, vB0, vB1, tw;
    ae_int32x2 * restrict p_x0,
               * restrict p_x1,
               * restrict p_y0,
               * restrict p_y1;
    ae_int64 *restrict ptw = (ae_int64*)(twiddle_table + twiddle_stride);

    int  n;
    int shift = 1;

    XT_MOVNEZ(shift, 0, bexp); 
    WUR_AE_SAR(shift+1);

    p_x0 = (ae_int32x2 *)(y);
    p_x1 = (ae_int32x2 *)(y + N / 2 - 1);
    p_y0 = (ae_int32x2 *)(y);
    p_y1 = (ae_int32x2 *)(y + N / 2);

    //    pX1 =  (ae_int32x4*) ((complex_fract32 *)y + N / 2 - 2);
    /*
    b0 = y[0];
    b0.s.re >>= shift;
    b0.s.im >>= shift;

    a0.s.re = L_add_ll(b0.s.re, b0.s.im);
    a0.s.im = 0;
    a1.s.re = L_sub_ll(b0.s.re, b0.s.im);
    a1.s.im = 0;

    a1 = conj_fr32c(a1);
    y[0] = a0;
    y[N / 2] = a1;
    */
    WUR_AE_SAR(shift + 1);

    AE_L32X2_IP(vB0, p_x0, sizeof(complex_fract32));
    vB0 = AE_SRAA32(vB0, shift);

    vB1 = AE_MUL32JS(vB0);
    vB0 = AE_ADD32S(vB0, vB1);

    vA1 = AE_SEL32_HH(vB0, AE_MOVI(0));
    vA0 = AE_SEL32_LL(vB0, AE_MOVI(0));
    AE_S32X2_IP(vA0, p_y0, sizeof(complex_fract32));
    AE_S32X2_XP(vA1, p_y1, -(int)sizeof(complex_fract32));

    __Pragma("loop_count min=3");
    for (n = 1; n < N / 4; n++)
    {
        ae_int64 t64;
        AE_L64_XP(t64, ptw, twiddle_stride*sizeof(complex_fract32));
        tw = AE_MOVINT32X2_FROMINT64(t64);
        AE_L32X2_IP(vB0, p_x0, sizeof(complex_fract32));
        AE_L32X2_XP(vB1, p_x1, -(int)sizeof(complex_fract32));

        // ADD/SUBB
        AE_ADDANDSUBRNG32(vA0, vA1, vB0, vB1);

        vB1 = AE_SEL32_HL(AE_NEG32S(vA1), vA0);
        vB0 = AE_SEL32_HL(vA0, vA1);

        vB1 = AE_MULFC32RAS(vB1, tw);

        vA0 = AE_SUBADD32S(vB0, vB1);
        vA1 = AE_ADDSUB32S(vB1, vB0);

        AE_S32X2_IP(vA0, p_y0, sizeof(complex_fract32));
        AE_S32X2_XP(vA1, p_y1, -(int)sizeof(complex_fract32));
    }

    vA0 = AE_L32X2_I(p_x0, 0);
    vA0 = AE_SRAA32(vA0, shift);
    _CONJ32(vA0);  /* a0 = conj(a0) */
    AE_S32X2_I(vA0, p_y0, 0);

    return shift;
} /* SpectrConv */

/*-------------------------------------------------------------------------
  FFT on Real Data with Optimized Memory Usage
  These functions make FFT on real data forming half of spectrum with
  optimized memory usage.
  Scaling: 
      +-----------------------+--------------------------------------+
      |      Function         |           Scaling options            |
      +-----------------------+--------------------------------------+
      |  fft_real16x16_ie     |  2 - 16-bit dynamic scaling          |
      |  fft_real32x16_ie     |  2 - 32-bit dynamic scaling          |
      |                       |  3 - fixed scaling before each stage |
      |  fft_real32x32_ie     |  2 - 32-bit dynamic scaling          |
      |                       |  3 - fixed scaling before each stage |
      +-----------------------+--------------------------------------+
    
  NOTES:
  1. Bit-reversing reordering is done here.
  2. INPUT DATA MAY APPEAR DAMAGED after the call.
  3. FFT functions may use input and output buffers for temporal storage
     of intermediate 32-bit data, so FFT functions with 24-bit packed
     I/O (Nx3-byte data) require that the buffers are large enough to 
     keep Nx4-byte data.
  4. FFT of size N may be supplied with constant data (twiddle factors) 
     of a larger-sized FFT = N*twdstep.

  Precision:
  16x16_ie      16-bit input/outputs, 16-bit data, 16-bit twiddles
  32x16_ie      32-bit input/outputs, 32-bit data, 16-bit twiddles
  32x32_ie      32-bit input/outputs, 32-bit data, 32-bit twiddles
  f_ie          floating point

  Input:
  x                     input signal: 
  --------------+----------+-----------------+----------+
  Function      |   Size   |  Allocated Size |  type    |
  --------------+----------+-----------------+-----------
  16x16_ie      |     N    |      N          |  int16_t |
  32x16_ie      |     N    |      N          |  int32_t |
  32x32_ie      |     N    |      N          |  int32_t |
  f_ie          |     N    |      N          |float32_t |
  --------------+----------+-----------------+----------+

  twd[N*twdstep*3/4]    twiddle factor table of a complex-valued 
                        FFT of size N*twdstep
  N                     FFT size
  twdstep               twiddle step
  scalingOpt            scaling option (see table above), not applicable 
                        to the floating point function

  Output:
  y                     output spectrum. Real and imaginary data 
                        are interleaved and real data goes first:
  --------------+----------+-----------------+---------------+
  Function      |   Size   |  Allocated Size |  type         |
  --------------+----------+-----------------+----------------
  16x16_ie      |   N/2+1  |      N/2+1      |complex_fract16|
  32x16_ie      |   N/2+1  |      N/2+1      |complex_fract32|
  32x32_ie      |   N/2+1  |      N/2+1      |complex_fract32|
  f_ie          |   N/2+1  |      N/2+1      |complex_float  |
  --------------+----------+-----------------+---------------+

  Returned value: total number of right shifts occurred during scaling
  procedure

  Restrictions:
  x,y     should not overlap
  x,y     aligned on 16-bytes boundary
-------------------------------------------------------------------------*/
int fft_real32x32_ie(complex_fract32* y, int32_t  * x, const complex_fract32* twd, int twdstep, int N, int scalingOpt)
{
    int shift;
    int bexp; 

    NASSERT(scalingOpt==2 || scalingOpt==3); 
    NASSERT((void*)x != (void*)y);
    NASSERT_ALIGN16(x); 
    NASSERT_ALIGN16(y);
    NASSERT_ALIGN16(twd);

    shift = fft_cplx32x32_ie(y, (complex_fract32*)x, twd, twdstep*2, N/2, scalingOpt);

    if (scalingOpt == 2)
    {
        AE_CALCRNG3(); 
        bexp = 3 - RUR_AE_SAR();
    }
    else
    {
        bexp = 0;
    }

    shift += SpectrConv(y, N, twd, 3*twdstep, scalingOpt, bexp);

    return shift;  
} /* fft_real32x32_ie() */
