/*
  NatureDSP Signal Processing Library. FIR part
    Real data circular cross-correlation, complex 32x32, no requirements on vectors
    length and alignment.
    C code optimized for HiFi5
  IntegrIT, 2006-2019
*/

/* Portable data types. */
#include "NatureDSP_types.h"
/* Signal Processing Library API. */
#include "NatureDSP_Signal_fir.h"
/* Common utility and macros declarations. */
#include "common.h"

/*-------------------------------------------------------------------------
  Circular Correlation
  Estimates the circular cross-correlation between vectors x (of length N) 
  and y (of length M)  resulting in vector r of length N. It is a similar 
  to correlation but x is read in opposite direction.
  These functions implement the circular correlation algorithm with no 
  limitations on x and y vectors length and alignment at the cost of 
  increased processing complexity. In addition, this implementation variant
  requires scratch memory area.

  Precision: 
  16x16     16x16-bit data, 16-bit outputs
  32x16     32x16-bit data, 32-bit outputs
  32x32     32x32-bit data, 32-bit outputs
  32x32ep   the same as above but using 72-bit accumulator for intermediate 
            computations
  f         floating point

  Input:
  s[]       scratch area, 
              FIR_XCORRA16X16_SCRATCH_SIZE( N, M )
              FIR_XCORRA32X16_SCRATCH_SIZE( N, M ) or
              FIR_XCORRA32X32_SCRATCH_SIZE( N, M ) or
              FIR_XCORRA32X32EP_SCRATCH_SIZE( N, M ) or
              FIR_XCORRAF_SCRATCH_SIZE( N, M ) or
              CXFIR_XCORRA32X32_SCRATCH_SIZE( N, M ) or
              CXFIR_XCORRAF_SCRATCH_SIZE( N, M ) bytes

  x[N]      input data Q15, Q31 or floating point
  y[M]      input data Q15, Q31 or floating point
  N         length of x
  M         length of y
  Output:
  r[N]      output data, Q15, Q31 or floating point

  Restrictions:
  x,y,r,s   should not overlap
  s         must be aligned on an 16-bytes boundary
  N,M       must be >0
  N >= M-1  minimum allowed length of vector x is the length of y minus one

-------------------------------------------------------------------------*/

void cxfir_xcorra32x32( void            * restrict s,
                        complex_fract32 * restrict r,
                  const complex_fract32 * restrict x,
                  const complex_fract32 * restrict y,
                  int N, int M )
{
    //
    // Circular cross-correlation algorithm:
    //
    //   r[n] = sum( x[mod(n+m,N)]*y[m] )
    //        m=0..M-1
    //
    //   where n = 0..N-1
    //
    const ae_int32x2 * restrict pX;
    const ae_int64   * restrict pY;
          ae_int32x2 * restrict pR;

    ae_f64 q0_re, q1_re, q2_re, q3_re;
    ae_f64 q0_im, q1_im, q2_im, q3_im;
    ae_int32x2 X0, X1, X2, X3, Y;
    ae_int64 Y_;

    int n, m;

    //NASSERT(s);
    NASSERT(r);
    NASSERT(x);
    NASSERT(y);
    NASSERT_ALIGN(s, 16);
    NASSERT_ALIGN(r, 8);
    NASSERT_ALIGN(x, 8);
    NASSERT_ALIGN(y, 8);
    (void)s;
    NASSERT(N > 0 && M > 0);
    NASSERT(N >= M - 1);

    pR = (ae_int32x2*)r;
    /* set circular buffer boundaries */
    WUR_AE_CBEGIN0((uintptr_t)(x + 0));
    WUR_AE_CEND0  ((uintptr_t)(x + N));

    for (n = 0; n < (N >> 3); n++)
    {
        ae_f64 q4_re, q5_re, q6_re, q7_re;
        ae_f64 q4_im, q5_im, q6_im, q7_im;
        ae_int32x2 X4, X5, X6, X7;

        pX = (const ae_int32x2 *)(x + 8 * n);
        pY = (const ae_int64   *)y;
        q0_re = q1_re = q2_re = q3_re = AE_ZERO64();
        q0_im = q1_im = q2_im = q3_im = AE_ZERO64();
        q4_re = q5_re = q6_re = q7_re = AE_ZERO64();
        q4_im = q5_im = q6_im = q7_im = AE_ZERO64();
        /* preload data from x */
        AE_L32X2_XC(X0, pX, sizeof(complex_fract32));
        AE_L32X2_XC(X1, pX, sizeof(complex_fract32));
        AE_L32X2_XC(X2, pX, sizeof(complex_fract32));
        AE_L32X2_XC(X3, pX, sizeof(complex_fract32));
        AE_L32X2_XC(X4, pX, sizeof(complex_fract32));
        AE_L32X2_XC(X5, pX, sizeof(complex_fract32));
        AE_L32X2_XC(X6, pX, sizeof(complex_fract32));

        __Pragma("loop_count min=1");
        for (m = 0; m < M; m++)
        {
            /* load data from x */
            AE_L32X2_XC(X7, pX, sizeof(complex_fract32));
            /* load data from y */
            AE_L64_IP(Y_, pY, sizeof(complex_fract32));
            Y = AE_MOVINT32X2_FROMINT64(Y_);
            /* compute correlation of 8 values */
            AE_MULAFC32RA(q0_im, q0_re, X0, Y);
            AE_MULAFC32RA(q1_im, q1_re, X1, Y);
            AE_MULAFC32RA(q2_im, q2_re, X2, Y);
            AE_MULAFC32RA(q3_im, q3_re, X3, Y);
            AE_MULAFC32RA(q4_im, q4_re, X4, Y);
            AE_MULAFC32RA(q5_im, q5_re, X5, Y);
            AE_MULAFC32RA(q6_im, q6_re, X6, Y);
            AE_MULAFC32RA(q7_im, q7_re, X7, Y);
            /* shift input line for the next iteration */
            X0 = X1; X1 = X2; X2 = X3;
            X3 = X4; X4 = X5; X5 = X6; X6 = X7;
        }
        /* save computed samples */
        X0 = AE_ROUND32X2F48SASYM(q0_re, q0_im);
        X1 = AE_ROUND32X2F48SASYM(q1_re, q1_im);
        X2 = AE_ROUND32X2F48SASYM(q2_re, q2_im);
        X3 = AE_ROUND32X2F48SASYM(q3_re, q3_im);
        AE_S32X2_IP(X0, pR, sizeof(complex_fract32));
        AE_S32X2_IP(X1, pR, sizeof(complex_fract32));
        AE_S32X2_IP(X2, pR, sizeof(complex_fract32));
        AE_S32X2_IP(X3, pR, sizeof(complex_fract32));
        X0 = AE_ROUND32X2F48SASYM(q4_re, q4_im);
        X1 = AE_ROUND32X2F48SASYM(q5_re, q5_im);
        X2 = AE_ROUND32X2F48SASYM(q6_re, q6_im);
        X3 = AE_ROUND32X2F48SASYM(q7_re, q7_im);
        AE_S32X2_IP(X0, pR, sizeof(complex_fract32));
        AE_S32X2_IP(X1, pR, sizeof(complex_fract32));
        AE_S32X2_IP(X2, pR, sizeof(complex_fract32));
        AE_S32X2_IP(X3, pR, sizeof(complex_fract32));
    }
    if (N & 4)
    {
        pX = (const ae_int32x2 *)(x + 8 * n);
        pY = (const ae_int64   *)y;
        q0_re = q1_re = q2_re = q3_re = AE_ZERO64();
        q0_im = q1_im = q2_im = q3_im = AE_ZERO64();
        /* preload data from x */
        AE_L32X2_XC(X0, pX, sizeof(complex_fract32));
        AE_L32X2_XC(X1, pX, sizeof(complex_fract32));
        AE_L32X2_XC(X2, pX, sizeof(complex_fract32));

        __Pragma("loop_count min=1");
        for (m = 0; m < M; m++)
        {
            /* load data from x */
            AE_L32X2_XC(X3, pX, sizeof(complex_fract32));
            /* load data from y */
            AE_L64_IP(Y_, pY, sizeof(complex_fract32));
            Y = AE_MOVINT32X2_FROMINT64(Y_);
            /* compute correlation of 4 values */
            AE_MULAFC32RA(q0_im, q0_re, X0, Y);
            AE_MULAFC32RA(q1_im, q1_re, X1, Y);
            AE_MULAFC32RA(q2_im, q2_re, X2, Y);
            AE_MULAFC32RA(q3_im, q3_re, X3, Y);
            /* shift input line for the next iteration */
            X0 = X1; X1 = X2; X2 = X3;
        }
        /* save computed samples */
        X0 = AE_ROUND32X2F48SASYM(q0_re, q0_im);
        X1 = AE_ROUND32X2F48SASYM(q1_re, q1_im);
        X2 = AE_ROUND32X2F48SASYM(q2_re, q2_im);
        X3 = AE_ROUND32X2F48SASYM(q3_re, q3_im);
        AE_S32X2_IP(X0, pR, sizeof(complex_fract32));
        AE_S32X2_IP(X1, pR, sizeof(complex_fract32));
        AE_S32X2_IP(X2, pR, sizeof(complex_fract32));
        AE_S32X2_IP(X3, pR, sizeof(complex_fract32));
    }
    /* Compute last (N%3) samples */
    for (n = (N&~3); n < N; n++)
    {
        pX = (const ae_int32x2 *)(x + n);
        pY = (const ae_int64   *)y;
        q0_re = q0_im = AE_ZERO64();
        __Pragma("loop_count min=1");
        for (m = 0; m < M; m++)
        {
            AE_L32X2_XC(X0, pX, sizeof(complex_fract32));
            AE_L64_IP(Y_, pY, sizeof(complex_fract32));
            Y = AE_MOVINT32X2_FROMINT64(Y_);
            /* compute correlation of 4 values */
            AE_MULAFC32RA(q0_im, q0_re, X0, Y);
        }
        X0 = AE_ROUND32X2F48SASYM(q0_re, q0_im);
        AE_S32X2_IP(X0, pR, sizeof(complex_fract32));
    }
} // cxfir_xcorra32x32()
