/*
  NatureDSP Signal Processing Library. FIR part
    Real data circular auto-correlation, 16x16-bit
    C code optimized for HiFi5
  IntegrIT, 2006-2019
*/

/* Portable data types. */
#include "NatureDSP_types.h"
/* Signal Processing Library API. */
#include "NatureDSP_Signal_fir.h"
/* Common utility and macros declarations. */
#include "common.h"

/*-------------------------------------------------------------------------
  Circular Autocorrelation 
  Estimates the auto-correlation of vector x. Returns autocorrelation of 
  length N.

  Precision: 
  16x16     16-bit data, 16-bit outputs
  32x32     32-bit data, 32-bit outputs
  32x32ep   the same as above but using 72-bit accumulator for intermediate 
            computations
  f         floating point

  Input:
  x[N]      input data, Q15, Q31 or floating point
  N         length of x
  Output:
  r[N]      output data, Q15, Q31 or floating point

  Restrictions:
  x,r       should not overlap
  x,r       aligned on an 16-bytes boundary
  N         multiple of 4 and >0
-------------------------------------------------------------------------*/

void fir_acorr16x16( int16_t * restrict r,
               const int16_t * restrict x,
               int N )
{
  NASSERT(x);
  NASSERT(r);
  NASSERT_ALIGN(x,8);
  NASSERT_ALIGN(r,8);
  NASSERT(N>0 && (N%4)==0);
  fir_xcorr16x16(r,x,x,N,N);
} /* fir_acorr16x16() */
