/*
 * NatureDSP_Signal Library API
 * Mel-frequency cepstrum coefficients extraction
 * Function annotations
 */

/* Portable data types. */
#include "NatureDSP_types.h"
/* NatureDSP_Signal Library MFCC features extraction API. */
#include "NatureDSP_Signal_audio.h"
/* Common utility declarations. */
#include "common.h"

ANNOTATE_FUN(logmel32x32_process, "Compute log mel filterbank energies (32-bit fixed-point input/output data)                     ");
ANNOTATE_FUN(logmelf_process    , "Compute log mel filterbank energies (single precision floating-point input/output data)        ");
ANNOTATE_FUN(mfcc32x32_process  , "Compute Mel-Frequency Cepstrum Coefficients (32-bit fixed-point input/output data)             ");
ANNOTATE_FUN(mfccf_process      , "Compute Mel-Frequency Cepstrum Coefficients (single precision floating-point input/output data)");
ANNOTATE_FUN(htkdelta32x32      , "Compute first order regression coefficients (32-bit fixed-point input/output data)             ");
ANNOTATE_FUN(htkdeltaf          , "Compute first order regression coefficients (single precision floating-point input/output data)");
