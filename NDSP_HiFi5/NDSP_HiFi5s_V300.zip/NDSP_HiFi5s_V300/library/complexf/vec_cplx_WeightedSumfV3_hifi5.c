
#include "common.h"
#include "common_fpu.h"
#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_WeightedSumfV3,(	complex_float* restrict cwsy, complex_float* restrict x0, complex_float* restrict x1,
		complex_float* restrict w,  int N ))
#elif HAVE_VFPU
/*  complexWeightedSum_V3 Vector
	CWS[i] = X0[i] + (W[i] o X1[i])
	where X1, X2 & W are complex-valued vectors, and o is the Hadamard product
*/
void vec_cplx_WeightedSumfV3(	complex_float* restrict cwsy, complex_float* restrict x0, complex_float* restrict x1,
									complex_float* restrict w,  int N )
{
   const xtfloatx4* restrict px0;
   const xtfloatx4* restrict px1;
   const xtfloatx4* restrict pw;
         xtfloatx4* restrict pcwsy;
   int i;
   xtfloatx2 x10, x11, w0, w1;
   xtfloatx2 r0, r1;

   NASSERT(cwsy);
   NASSERT(x0);
   NASSERT(x1);
   NASSERT(w);
   NASSERT_ALIGN(cwsy, 16);
   NASSERT_ALIGN(x0, 16);
   NASSERT_ALIGN(x1, 16);
   NASSERT_ALIGN(w, 16);
   NASSERT(N > 0 && N % 2 == 0);
   if(N<0) return;

   px0 = (xtfloatx4*)x0;
   px1 = (xtfloatx4*)x1;
   pw =  (xtfloatx4*)w;
   pcwsy = (xtfloatx4*)cwsy;
   for(i=0; i<N>>1; i++)
   {
	   AE_LSX2X2_IP(x10, x11, px1, sizeof(xtfloatx4));	// Load X1
	   AE_LSX2X2_IP(r0,  r1,  px0, sizeof(xtfloatx4));	// Load X0
	   AE_LSX2X2_IP(w0,  w1,  pw,  sizeof(xtfloatx4));	// Load W
	   MADDC_SX2(r0, r1, x10, x11, w0, w1);
	   AE_SSX2X2_IP(r0, r1, pcwsy, sizeof(xtfloatx4));
   }
}
#endif
