/*  Complex Norm
	cplxnorm[n] = x[n] / euclidean_norm(x[n])
	where x = a + jb;
	Inputs  : X is complex-valued vector of length N
	Outputs : cny is a complex valued vector of length N
	Not tested for input special numbers (output can be special numbers)
	xreal/sqrt(xreal^2+ximag^2), ximag/sqrt(xreal^2+ximag^2)
*/
#include "common.h"
#include "common_fpu.h"

#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_Normf,(complex_float* cny, complex_float* restrict x, int N))
#elif HAVE_VFPU

void vec_cplx_Normf(complex_float* cny, complex_float* restrict x, int N)
{
	const xtfloatx4 *px;
	xtfloatx4 *pcny;
	xtfloatx2 xR, xI;
	int i;

	xtfloatx2 x10, x11;
	xtfloatx2 rt0, rt1;
	xtfloatx2 r0, r1;
	if(N<0) return;
	xtfloatx2 const_1 = CONST_SX2(1);
	px  = (xtfloatx4*)x;
	pcny = (xtfloatx4*)cny;
	for(i=0; i< (N>>1); i++)
	{
		AE_LSX2X2_IP(x10, x11, px,  sizeof(xtfloatx4));	// Load X

		xR = AE_SEL32_HH_SX2(x10, x11);
		xI = AE_SEL32_LL_SX2(x10, x11);
		MUL_SX2X2(xR, xI, xR, xI, xR, xI);
		xR = ADD_SX2(xR,xI);
		rt0 = SQRT_SX2(xR);
		rt0 = DIV_SX2(const_1, rt0);
		rt1 = AE_SEL32_LL_SX2(rt0, rt0);
		rt0 = AE_SEL32_HH_SX2(rt0, rt0);
		MUL_SX2X2(r0,r1,x10,x11,rt0,rt1);
		AE_SSX2X2_IP(r0, r1, pcny, sizeof(xtfloatx4));
	}
}
#endif
