
#include "common.h"
#include "common_fpu.h"
#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_WeightedSum_hmfV1,(complex_float* restrict cwsy, complex_float* restrict x1, complex_float* restrict x2,
		   complex_float* restrict w1, complex_float* restrict w2,
		   int N))
#elif HAVE_VFPU
/*  vec_cplx_WeightedSum_hmfV1 Vector
	CWS[i] = (W1[i] o X1[i]) + (W2[i] o X2[i])
	where X1, X2, W1, W2 and are complex-valued vectors, and o  is the Hadamard product
*/

void vec_cplx_WeightedSum_hmfV1(complex_float* restrict cwsy, complex_float* restrict x1, complex_float* restrict x2,
								   complex_float* restrict w1, complex_float* restrict w2,
								   int N)
{
   const xtfloatx4* restrict px1;
   const xtfloatx4* restrict px2;
   const xtfloatx4* restrict pw1;
   const xtfloatx4* restrict pw2;
   	   	 xtfloatx4* restrict pcwsy;
   int i;
   xtfloatx2 x10, x11, x20, x21, w10, w11, w20, w21;
   xtfloatx2 r0, r1;

   NASSERT(cwsy);
   NASSERT(x1);
   NASSERT(x2);
   NASSERT(w1);
   NASSERT(w2);
   NASSERT_ALIGN(cwsy, 16);
   NASSERT_ALIGN(x1, 16);
   NASSERT_ALIGN(x2, 16);
   NASSERT_ALIGN(w1, 16);
   NASSERT_ALIGN(w2, 16);
   NASSERT(N > 0 && N % 2 == 0);
   if(N<0) return;

   px1 = (xtfloatx4*)x1;
   px2 = (xtfloatx4*)x2;
   pw1 = (xtfloatx4*)w1;
   pw2 = (xtfloatx4*)w2;
   pcwsy = (xtfloatx4*)cwsy;
   for(i=0; i<N>>1; i++)
   {
	   AE_LSX2X2_IP(x10, x11, px1, sizeof(xtfloatx4));	// Load X1
	   AE_LSX2X2_IP(w10, w11, pw1, sizeof(xtfloatx4));	// Load W1
	   MULMUX_SX2X2 (r0, r1, x10, x11, w10, w11, 1);//HH  -HL  ->   [RR , -RI]
	   MADDMUX_SX2X2(r0, r1, x10, x11, w10, w11, 5); //LL

	   AE_LSX2X2_IP(x20, x21, px2, sizeof(xtfloatx4));	// Load X2
	   AE_LSX2X2_IP(w20, w21, pw2, sizeof(xtfloatx4));	// Load W2
	   MADDMUX_SX2X2(r0, r1, x20, x21, w20, w21, 4);//HH  -HL  ->   [RR , -RI]
	   MADDMUX_SX2X2(r0, r1, x20, x21, w20, w21, 5); //LL

	   AE_SSX2X2_IP(r0,r1,pcwsy, sizeof(xtfloatx4));	// Store result
   }
}
#endif
