
/* This is time domain cross correlation
 * which is equivalent to frequency domain multiplication with complex conj.
 * Therefore Eventhough name is Xcorr, this is multiplication with conj.
 * x, y: inputs both must be of same length and complex
 * r: output (complex)
 * input and output length is same
 */
#include "common.h"
#include "common_fpu.h"

#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,cxfir_FreqXcorrf,(complex_float * restrict r,
		const complex_float * restrict x,
		const complex_float * restrict y,
		int N))
#elif HAVE_VFPU
void cxfir_FreqXcorrf(complex_float * restrict r,
				const complex_float * restrict x,
				const complex_float * restrict y,
				int N)
{
    const xtfloatx4 * restrict pX;
    const xtfloatx4 * restrict pY;
          xtfloatx4 * restrict pR;
          xtfloatx2 r00,  r10;
          xtfloatx2 r02,  r12;
    xtfloatx2 x0, x1, y0, y1;
    int i;

    NASSERT(r);
    NASSERT(x);
    NASSERT(y);
	NASSERT_ALIGN(r, 16);
	NASSERT_ALIGN(x, 16);
	NASSERT_ALIGN(y, 16);
	NASSERT(N > 0 && N % 4 == 0);

	pX = (const xtfloatx4 *)x;
	pY = (const xtfloatx4 *)y;
	pR = (xtfloatx4 *)r;
	for(i=0;i<(N>>2);i++) //works only when N is multiple of 4, 4 complex elements
	{
	    AE_LSX2X2_IP(x0, x1, pX, sizeof(xtfloatx4));
	    AE_LSX2X2_IP(y0, y1, pY, sizeof(xtfloatx4));
	    MULMUX_SX2X2 (r00, r10, x0, x1, y0, y1, 1);//HH  -HL  ->   [RR , -RI]
	    MADDMUX_SX2X2(r00, r10, x0, x1, y0, y1, 5); //LL
	    AE_SSX2X2_IP(r00, r10, pR, sizeof(xtfloatx4));
	    //---------------------------------------------------------------------------------------------
	    AE_LSX2X2_IP(x0, x1, pX, sizeof(xtfloatx4));
	    AE_LSX2X2_IP(y0, y1, pY, sizeof(xtfloatx4));
	    MULMUX_SX2X2 (r02, r12, x0, x1, y0, y1, 1);//HH  -HL  ->   [RR , -RI]
	    MADDMUX_SX2X2(r02, r12, x0, x1, y0, y1, 5); //LL
	    AE_SSX2X2_IP(r02, r12, pR, sizeof(xtfloatx4));
	    //---------------------------------------------------------------------------------------------
	}
}
#endif
