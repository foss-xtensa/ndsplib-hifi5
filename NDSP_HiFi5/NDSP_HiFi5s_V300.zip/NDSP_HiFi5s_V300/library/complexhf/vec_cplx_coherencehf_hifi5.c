/*Inputs: x0, x1 half precision complex floating point vectors
 * Output: ccohy -complex half precision float vector (complex coherence of inputs x0, x1)
 * Operation:
 * num = x0_cpx.*conj(x1_cpx);
 * x0mag = abs(x0_cpx);
 * x1mag = abs(x1_cpx);
 * normVal = num.*(1./x0mag).*(1./x1mag);
 *
 */
#include "common.h"
#include "common_fpu.h"

#if  !XCHAL_HAVE_HIFI5_HP_VFPU && !XCHAL_HAVE_HIFI5S_HP_VFPU
DISCARD_FUN(void,vec_cplx_Coherencehf,(complex_float16* ccohy, complex_float16* restrict x0,
		  complex_float16* restrict x1, int N))
#elif XCHAL_HAVE_HIFI5_HP_VFPU || XCHAL_HAVE_HIFI5S_HP_VFPU
void vec_cplx_Coherencehf(complex_float16* ccohy, complex_float16* restrict x0,
						  complex_float16* restrict x1, int N)
{
   const xthalfx8 *px0, *px1;
   xthalfx8 *pccohy;
   int i;
   xthalfx4 x00, x01, x10, x11;
   xthalfx4 x00Conj_IR, x10Conj_IR, x01Conj_IR, x11Conj_IR;
   xthalfx4 n0R,n0I, n1R, n1I, n0_H, n0_L, n1_H, n1_L, n0Real,n0Img,n1Real, n1Img;
   xthalfx4 x00x00, x01x01, x10x10, x11x11, x01_RR,x01_II, x11_RR, x11_II;
   xthalfx4 n0, n1, d0, d1, y0, y1;

   NASSERT(x0);
   NASSERT(x1);
   NASSERT(ccohy);
   NASSERT_ALIGN(x0, 16);
   NASSERT_ALIGN(x1, 16);
   NASSERT_ALIGN(ccohy, 16);
   NASSERT(N > 0 && N % 8 == 0);
   if(N<0) return;
   px0 = (xthalfx8*)x0;
   px1 = (xthalfx8*)x1;
   pccohy = (xthalfx8*)ccohy;
   xthalfx4 constInf, constZero;
   constInf = AE_MOVXTHALFX4_FROMINT16X4(AE_MOVINT16X4_FROMINT16(0x7c00));
   constZero = AE_MOVXTHALFX4_FROMINT16X4(AE_MOVINT16X4_FROMINT16(0x0000));
   xtbool4  Inf_Flag;
   //recip intrinsic result is Ind for inf input, need to add special check
   for(i=0; i<N>>2; i++)
   {
	   AE_LHX4X2_IP(x00,x01,px0,sizeof(xthalfx8));	// Load X0
	   AE_LHX4X2_IP(x10,x11,px1,sizeof(xthalfx8));	// Load X0

	   MULJC_HX4X2(x00Conj_IR,x01Conj_IR,x00, x01 );
	   MULJC_HX4X2(x10Conj_IR,x11Conj_IR,x10, x11 );

//------------------numerator: x0 o conj(x1)-------------------------------------------
	   MUL_HX4X2(n0R, n1R, x00, x01, x10, x11);
	   MUL_HX4X2(n0I, n1I, x00, x01, x10Conj_IR, x11Conj_IR);

	   n0_H = AE_SELH_7362(n0R,n0I);
	   n0_L = AE_SELH_5140(n0R,n0I);

	   n1_H = AE_SELH_7362(n1R,n1I);
	   n1_L = AE_SELH_5140(n1R,n1I);


	   n0Real = AE_SELH_7632(n0_H,n0_L);
	   n0Img  = AE_SELH_5410(n0_H,n0_L);

	   n1Real = AE_SELH_7632(n1_H,n1_L);
	   n1Img  = AE_SELH_5410(n1_H,n1_L);

	   ADD_HX4X2 (n0,n1,n0Real,n1Real,n0Img,n1Img);
//---------------------------------------------------------------------------------------
//------------------denominator: inverse of sqrt(x0 o conj(x0) X sqrt(x1 o conj(x1))----------------------
	   MUL_HX4X2(x00x00, x01x01, x00, x01, x00, x01);
	   MUL_HX4X2(x10x10, x11x11, x10, x11, x10, x11);

	   x01_RR = AE_SELH_7531(x00x00,x01x01);
	   x01_II = AE_SELH_6420(x00x00,x01x01);

	   x11_RR = AE_SELH_7531(x10x10,x11x11);
	   x11_II = AE_SELH_6420(x10x10,x11x11);

	   ADD_HX4X2(d0,d1,x01_RR,x11_RR,x01_II,x11_II);

	   d0 = SQRT_HX4(d0);
	   d1 = SQRT_HX4(d1);

	   d0 = MUL_HX4(d0, d1);
	   Inf_Flag = OEQ_HX4(d0,constInf);
	   d0 = RECIP_HX4(d0);
	   MOVT_HX4(d0,constZero,Inf_Flag);
	   d1 = AE_SELH_5140(d0,d0);
	   d0 = AE_SELH_7362(d0,d0);

	   MUL_HX4X2(y0, y1, n0, n1, d0, d1); //multiply numerator by inverse
	   //---------------------------------------------------------------------------------------
	   AE_SHX4X2_IP(y0,y1,pccohy, sizeof(xthalfx8));

   }
}
#endif
