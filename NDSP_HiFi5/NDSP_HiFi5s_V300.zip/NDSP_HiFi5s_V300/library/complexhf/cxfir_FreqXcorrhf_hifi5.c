/*
  NatureDSP Signal Processing Library. FIR part
    helper for correlation/convolution
    C code optimized for HiFi5
 */

/* This is time domain cross correlation
 * which is equivalent to frequency domain multiplication with complex conj.
 * Therefore Eventhough name is Xcorr, this is multiplication with conj.
 * x, y: inputs both must be of same length
 * r: output
 * N: input and output length is same
 * Restrictions: N must be multiple of 4
 * */
#include "common.h"
#include "common_fpu.h"

#if  !XCHAL_HAVE_HIFI5_HP_VFPU && !XCHAL_HAVE_HIFI5S_HP_VFPU
DISCARD_FUN(void,cxfir_FreqXcorrhf,(   complex_float16 * restrict r,
		const complex_float16 * restrict x,
		const complex_float16 * restrict y,
		int N))
#elif XCHAL_HAVE_HIFI5_HP_VFPU || XCHAL_HAVE_HIFI5S_HP_VFPU
void cxfir_FreqXcorrhf(   complex_float16 * restrict r,
				const complex_float16 * restrict x,
				const complex_float16 * restrict y,
				int N)
{
const xthalfx8* restrict pX;
        const xthalfx8* restrict pY;
        xthalfx8 * restrict pR;
        xthalfx4 x0, x1, y0, y1, z0, z1;
        xthalfx4 y0Conj_IR,y1Conj_IR;
        xthalfx4 z0RR,z1RR,z0RI,z1RI;

        ae_int16x4 zRR_Int, zRI_Int;
        ae_int16x4 zRInt, zIInt;
        xthalfx4 z0R, z1R, z0I, z1I;
        //---------------------------SEL Index to flip Real and Imag after MUL
        static const ALIGN(16) int16_t selIdxP1[4] = { 0x0607, 0x0203, 0x0405, 0x0001 };
        ae_int16x4 selIdx1;
        selIdx1 = AE_L16X4_I((ae_int16x4*)&selIdxP1, 0);

        int i;
        NASSERT(r);
        NASSERT(x);
        NASSERT(y);
        NASSERT_ALIGN(r, 16);
        NASSERT_ALIGN(x, 16);
        NASSERT_ALIGN(y, 16);
        NASSERT(N > 0 && N % 4 == 0);

        pX = (const xthalfx8 *)x;
        pY = (const xthalfx8 *)y;
        pR = (xthalfx8 *)r;

        for(i=0;i<(N>>2);i++) //works only when M is multiple of 4, 4 complex elements
        {
            AE_LHX4X2_IP(x0, x1, pX, sizeof(xtfloatx4));
            AE_LHX4X2_IP(y0, y1, pY, sizeof(xtfloatx4));

            MULJC_HX4X2(y0Conj_IR, y1Conj_IR, y0, y1);

            MUL_HX4X2(z0RR, z1RR, x0, x1, y0, y1);
            MUL_HX4X2(z0RI, z1RI, x0, x1, y0Conj_IR, y1Conj_IR);

            zRR_Int = AE_MOVINT16X4_FROMXTHALFX4(z0RR);
            zRI_Int = AE_MOVINT16X4_FROMXTHALFX4(z0RI);
            AE_DSEL16X4(zRInt, zIInt, zRR_Int, zRI_Int, selIdx1); //arrange the elements for addition
            z0R = AE_MOVXTHALFX4_FROMINT16X4(zRInt);
            z0I = AE_MOVXTHALFX4_FROMINT16X4(zIInt);

            zRR_Int = AE_MOVINT16X4_FROMXTHALFX4(z1RR);
            zRI_Int = AE_MOVINT16X4_FROMXTHALFX4(z1RI);
            AE_DSEL16X4(zRInt, zIInt, zRR_Int, zRI_Int, selIdx1);
            z1R = AE_MOVXTHALFX4_FROMINT16X4(zRInt);
            z1I = AE_MOVXTHALFX4_FROMINT16X4(zIInt);

            ADD_HX4X2 (z0,z1,z0R,z1R,z0I,z1I);
            AE_SHX4X2_IP(z0,z1,pR, sizeof(xthalfx8));
        }
}
#endif
