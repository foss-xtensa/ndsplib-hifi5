/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */

#include "common.h"
#include "common_fpu.h"
#if  !XCHAL_HAVE_HIFI5_HP_VFPU && !XCHAL_HAVE_HIFI5S_HP_VFPU
DISCARD_FUN(void,vec_cplx_WeightedSumhfV2,(	complex_float16* cwsy, complex_float16* restrict x0, complex_float16* restrict x1,
		float16_t* restrict w, int N ))
#elif XCHAL_HAVE_HIFI5_HP_VFPU || XCHAL_HAVE_HIFI5S_HP_VFPU
/*  complexWeightedSumhfV2 Vector
	CWS[i] = (W[i] o X1[i]) + ((1-W[i]) o X2[i])
	where X1 & X2 are complex-valued vectors, W is a real-valued vector,  and o  is the Hadamard product
*/
void vec_cplx_WeightedSumhfV2(	complex_float16* cwsy, complex_float16* restrict x0, complex_float16* restrict x1,
		float16_t* restrict w, int N )
{
   const xthalfx8 *px0, *px1;
   const xthalfx4 *pw;
   xthalfx8 *pcwsy;
   int i;
   xthalfx4 x00, x01, x10, x11, wtmp, w00, w11, const_1,_1Mw00, _1Mw11;
   xthalfx4 r0, r1;

   NASSERT(cwsy);
   NASSERT(x0);
   NASSERT(x1);
   NASSERT(w);
   NASSERT_ALIGN(cwsy, 16);
   NASSERT_ALIGN(x0, 16);
   NASSERT_ALIGN(x1, 16);
   NASSERT_ALIGN(w, 16);
   NASSERT(N > 0 && N % 8 == 0);

   if(N<0) return;
   static const ALIGN(16) int16_t selIdxP1[4] = { 0x0705, 0x0301, 0x0604, 0x0200 };
   ae_int16x4 selIdx1;
   ae_int16x4 w0_Int, w1_Int;
   selIdx1 = AE_L16X4_I((ae_int16x4*)&selIdxP1, 0);

   px0 = (xthalfx8*)x0;
   px1 = (xthalfx8*)x1;
   pw =  (xthalfx4*)w;
   pcwsy = (xthalfx8*)cwsy;
   const_1 = CONST_HX4(1);
   for(i=0; i<N>>2; i++)
   {
	   AE_LHX4X2_IP(x00, x01, px0, sizeof(xthalfx8));	// Load X0
	   AE_LHX4X2_IP(x10, x11, px1, sizeof(xthalfx8));	// Load X1

	   AE_LHX4IP(wtmp, pw, sizeof(xthalfx4));			// Load wtmpH, wtmpL

	   w0_Int = AE_MOVINT16X4_FROMXTHALFX4(wtmp);
	   AE_DSEL16X4(w0_Int, w1_Int, w0_Int, w0_Int, selIdx1);
	   w00 = AE_MOVXTHALFX4_FROMINT16X4(w0_Int);
	   w11 = AE_MOVXTHALFX4_FROMINT16X4(w1_Int);

	   SUB_HX4X2(_1Mw00,_1Mw11,const_1,const_1,w00,w11);
	   MUL_HX4X2  (r0, r1, x00, x01, w00,w11);
	   MADD_HX4X2 (r0, r1, x10, x11, _1Mw00,_1Mw11);
	   AE_SHX4X2_IP(r0,r1,pcwsy, sizeof(xthalfx8));
   }
}
#endif
