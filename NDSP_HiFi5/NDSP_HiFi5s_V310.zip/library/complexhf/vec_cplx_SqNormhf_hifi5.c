/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */

#include "common.h"
#include <xtensa/sim.h>
#include "common_fpu.h"
#if  !XCHAL_HAVE_HIFI5_HP_VFPU && !XCHAL_HAVE_HIFI5S_HP_VFPU
DISCARD_FUN(void,vec_cplx_SqNormhf,(float16_t* csny, complex_float16* restrict x, int N))
#elif XCHAL_HAVE_HIFI5_HP_VFPU || XCHAL_HAVE_HIFI5S_HP_VFPU
/*  Complex Squared Norm :  Vector
	CSQN[i] = (X.real_sq[i] + X.img_sq[i])
	Inputs  : X is complex-valued vector of length N
	Outputs : csny is a real valued vector of length N
*/

#if 0 //less optimum and works when (XCHAL_HW_VERSION>=290030)
void vec_cplx_SqNormhf(float16_t* csny, complex_float16* restrict x, int N)
{
	xthalf *px;
	xthalf *pcsny;
	NASSERT(x);
	NASSERT(csny);
	NASSERT_ALIGN(x, 16);
	NASSERT_ALIGN(csny, 16);
	NASSERT(N > 0);
	int i;
	px  = (xthalf*)x;
	pcsny = (xthalf*)csny;
	int Idx=0;
	for(i=0; i< (N<<1); i+=2)
	{
		pcsny[Idx] = (px[i]*px[i])+(px[i+1]*px[i+1]);
		Idx++;
	}
}
#else
void vec_cplx_SqNormhf(float16_t* csny, complex_float16* restrict x, int N)
{
	const xthalfx8 *px;
	xthalfx4 *pcsny;
	int i;
	xthalfx4 x10, x11;
	xthalfx4 r0, r1;
	xthalfx4 r0IR, r1IR;
	if(N<0) return;
	px  = (xthalfx8*)x;
	pcsny = (xthalfx4*)csny;
	for(i=0; i< (N>>2); i++) //N multiples of 4
	{
		AE_LHX4X2_IP(x10, x11, px,  sizeof(xthalfx8));	// Load X
		MUL_HX4X2(r0, r1, x10, x11, x10, x11);
		r0IR = AE_SELH_2301(r0, r0);
		r1IR = AE_SELH_2301(r1, r1);
		ADD_HX4X2(r0,r1,r0,r1, r0IR,r1IR);
		r0 = AE_SELH_7520(r0, r1);
		AE_SHX4IP(r0,pcsny, sizeof(xthalfx4));
	}
	for(i=0;i<(N&3);i++)
	{
		xthalf x0real, x0img, r0real, r0img;
		AE_LHIP(x0real, castxcc(xthalf,px),  sizeof(xthalf));	// Load Xreal
		AE_LHIP(x0img, castxcc(xthalf,px),  sizeof(xthalf));	// Load Ximaginary
		r0real = MUL_H(x0real, x0real);
		r0img  = MUL_H(x0img, x0img);
		r0real = ADD_H(r0real,r0img);
		AE_SHIP(r0real, castxcc(xthalf,pcsny), sizeof(xthalf));	// store

	}
}
#endif
#endif
