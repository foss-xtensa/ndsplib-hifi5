/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */

#include "common.h"
#include "common_fpu.h"
#if  !XCHAL_HAVE_HIFI5_HP_VFPU && !XCHAL_HAVE_HIFI5S_HP_VFPU
DISCARD_FUN(void,vec_cplx_WeightedSumhfV1,(complex_float16* restrict y, complex_float16* restrict x0, complex_float16* restrict x1,
		complex_float16* restrict w0, complex_float16* restrict w1, int N))
#elif XCHAL_HAVE_HIFI5_HP_VFPU || XCHAL_HAVE_HIFI5S_HP_VFPU
/*  complexWeightedSumhfV1 Vector
	CWS[i] = (W1[i] o X1[i]) + (W2[i] o X2[i])
	where X1, X2, W1, W2 and are complex-valued vectors, and o  is the Hadamard product
*/
/* Implementation process
 * [x00r x00i] * [w00r + w00i] + [x10r x10i] * [w10r + w10i] to be implemented
 * r00r = [x00r*(-w00r) x00i*w00i, x01r*(-w01r), x01i*w01i] //need w0 and w1 conjugate for this
 * r00i = [x00r*w00i    x00i*w00r, x01r*  w01i , x01i*w01r] //use common multiplier x0 and x1
 * Adding higher two elements of r00r will give the real part of [x0r x0i] * [w0r + w0i]
 * however will involve many SEL, same for imag part, instead do below
 * load next elements
 * r00r += [x10r*(-w10r) x10i*w10i, x10r*(-w10r), x10i*w10i]
 * r00i += [x10r*w10i    x10i*w10r, x10r*  w10i , x10i*w10r]
 * Adding higher two elements of r00r will give the real part of final first element of result same for r00i
 * Do some rearrangements: No Direct SEL available available
 *
 */
void vec_cplx_WeightedSumhfV1(complex_float16* restrict y, complex_float16* restrict x0, complex_float16* restrict x1,
		complex_float16* restrict w0, complex_float16* restrict w1, int N)
{
   const xthalfx8* restrict px0;
   const xthalfx8* restrict px1;
   const xthalfx8* restrict pw0;
   const xthalfx8* restrict pw1;
   xthalfx8* restrict py;
   int i;
   xthalfx4 x00, x01, x10, x11, w00, w01, w10, w11;
   xthalfx4 r10r, r10i,r00r,r00i;
   xthalfx4 r0,r1,r2,r3;
   xthalfx4 w00Conj, w01Conj, w10Conj, w11Conj, w00LH, w01LH, w10LH, w11LH;

   NASSERT(y);
   NASSERT(x0);
   NASSERT(x1);
   NASSERT(w0);
   NASSERT(w1);
   NASSERT_ALIGN(y, 16);
   NASSERT_ALIGN(x0, 16);
   NASSERT_ALIGN(x1, 16);
   NASSERT_ALIGN(w0, 16);
   NASSERT_ALIGN(w1, 16);
   NASSERT(N > 0 && N % 8 == 0);
   if(N<0) return;
   static const ALIGN(16) int16_t selIdxP1[4] = { 0x0706, 0x0302, 0x0504, 0x0100 };
   ae_int16x4 selIdx1;
   ae_int16x4 rr_Int, ri_Int;
   selIdx1 = AE_L16X4_I((ae_int16x4*)&selIdxP1, 0);

   px0 = (xthalfx8*)x0;
   px1 = (xthalfx8*)x1;
   pw0 = (xthalfx8*)w0;
   pw1 = (xthalfx8*)w1;
   py = (xthalfx8*)y;

   for(i=0; i<N>>2; i++)
   {
	   AE_LHX4X2_IP(x00,x01,px0,sizeof(xthalfx8));	// Load X0
	   AE_LHX4X2_IP(w00,w01,pw0, sizeof(xthalfx8));	// Load W0

	   CONJC_HX4X2(w00Conj,  w01Conj, w00, w01); //wr, -wim


	   /* (x0r+jx0i)*(w0r+jw0i)
	    * [x0r*w0r + x0i*(-w0i)] [x0r*w0i + x0i*w0r]
	    */
	   w00LH = AE_SELH_2301(w00, w00); //flip the real and imag parts of wt
	   w01LH = AE_SELH_2301(w01, w01); //flip the real and imag parts of wt

	   AE_LHX4X2_IP(x10, x11, px1, sizeof(xthalfx8));	// Load X1
	   AE_LHX4X2_IP(w10, w11, pw1, sizeof(xthalfx8));	// Load W1

	   CONJC_HX4X2(w10Conj,  w11Conj, w10, w11); //wre, -wim
	   w10LH = AE_SELH_2301(w10, w10); //flip the real and imag parts of wt
	   w11LH = AE_SELH_2301(w11, w11); //flip the real and imag parts of wt

	   MULQ_H (r00r, r00i, w00Conj, w00LH, x00);
	   MULQ_H (r10r, r10i, w01Conj, w01LH, x01);

	   MADDQ_H(r00r, r00i, w10Conj, w10LH, x10);
	   MADDQ_H(r10r, r10i, w11Conj, w11LH, x11);

	   rr_Int = AE_MOVINT16X4_FROMXTHALFX4(r00r);
	   ri_Int = AE_MOVINT16X4_FROMXTHALFX4(r00i);
	   AE_DSEL16X4(rr_Int, ri_Int, rr_Int, ri_Int, selIdx1); //arrange the elements for addition
	   r0 = AE_MOVXTHALFX4_FROMINT16X4(rr_Int);
	   r1 = AE_MOVXTHALFX4_FROMINT16X4(ri_Int);

	   rr_Int = AE_MOVINT16X4_FROMXTHALFX4(r10r);
	   ri_Int = AE_MOVINT16X4_FROMXTHALFX4(r10i);
	   AE_DSEL16X4(rr_Int, ri_Int, rr_Int, ri_Int, selIdx1); //arrange the elements for addition
	   r2 = AE_MOVXTHALFX4_FROMINT16X4(rr_Int);
	   r3 = AE_MOVXTHALFX4_FROMINT16X4(ri_Int);


	   ADD_HX4X2(r0,r1, r0, r2, r1, r3); //result = r0+r1,   r2+r3
	   AE_SHX4X2_IP(r0,r1,py, sizeof(xthalfx8));	// Store result
   }
}
#endif
