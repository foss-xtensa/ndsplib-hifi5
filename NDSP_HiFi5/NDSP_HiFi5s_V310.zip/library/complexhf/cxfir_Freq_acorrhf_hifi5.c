/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
/*
  NatureDSP Signal Processing Library. FIR part
    helper for correlation/convolution
    C code optimized for HiFi5
 */

/* This is time domain auto correlation
 * which is equivalent to frequency domain multiplication with complex conj. X.X*
 * Therefore Eventhough name is acorr, this is multiplication with conj.
 * x: inputs both must be of same length and aligned
 * r: output
 * N: input and output length is same N must be multiple of 4
 *
 */
#include "common.h"
#include "common_fpu.h"

#if  !XCHAL_HAVE_HIFI5_HP_VFPU && !XCHAL_HAVE_HIFI5S_HP_VFPU
DISCARD_FUN(void,cxfir_Freq_acorrhf,(complex_float16* restrict r,
		const complex_float16* restrict x,
		int N))
#elif XCHAL_HAVE_HIFI5_HP_VFPU || XCHAL_HAVE_HIFI5S_HP_VFPU
void cxfir_Freq_acorrhf(complex_float16* restrict r,
				const complex_float16* restrict x,
				int N)
{
            const xthalfx8* restrict pX;
            xthalfx8* restrict pR;
            xthalfx4 x0, x1, z0, z1;

            //---------------------------SEL Index to flip Real and Imag
            static const ALIGN(16) int16_t selIdxP1[4] = { 0x0706, 0x0203, 0x0504, 0x0001 };
            ae_int16x4 selIdx1;
            selIdx1 = AE_L16X4_I((ae_int16x4*)&selIdxP1, 0);

            int i;
            NASSERT(r);
            NASSERT(x);

            NASSERT_ALIGN(r, 16);
            NASSERT_ALIGN(x, 16);

            NASSERT(N > 0 && N % 4 == 0);

            pX = (const xthalfx8 *)x;
            pR = (xthalfx8 *)r;
            for(i=0;i<(N>>2);i++) //works only when M is multiple of 4, 2 complex elements
            {
                AE_LHX4X2_IP(x0,x1, pX,sizeof(xthalfx8));

                ae_int16x4 x0Int, x1Int;
                ae_int16x4 x0RInt, x0IInt;
                ae_int16x4 x1RInt, x1IInt;
                xthalfx4 x0R,x0I,x1R,x1I;
                x0Int = AE_MOVINT16X4_FROMXTHALFX4(x0);
                x1Int = AE_MOVINT16X4_FROMXTHALFX4(x1);

                AE_DSEL16X4(x0RInt, x0IInt, x0Int, AE_MOV16(0), selIdx1);
                AE_DSEL16X4(x1RInt, x1IInt, x1Int, AE_MOV16(0), selIdx1);

                x0R = AE_MOVXTHALFX4_FROMINT16X4(x0RInt);
                x0I = AE_MOVXTHALFX4_FROMINT16X4(x0IInt);

                x1R = AE_MOVXTHALFX4_FROMINT16X4(x1RInt);
                x1I = AE_MOVXTHALFX4_FROMINT16X4(x1IInt);

                MUL_HX4X2(z0, z1, x0R, x1R, x0R, x1R); //r^2,i^2
                MADD_HX4X2(z0, z1, x0I, x1I, x0I, x1I); //r^2,i^2
                AE_SHX4X2_IP(z0,z1,pR, sizeof(xthalfx8));
            }   	  
}
#endif
