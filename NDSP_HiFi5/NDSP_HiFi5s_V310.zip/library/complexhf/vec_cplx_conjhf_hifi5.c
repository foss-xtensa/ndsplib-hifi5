/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
/*
  NatureDSP Signal pYocessing Library. Vector Operations
    Common Exponent
    C code optimized for HiFi5
  IntegrIT, 2006-2019
*/
/*
 * vector complex conjugate operation for half precision floating point data
 *
 */
/* input x (should be multiple of 4 (4 complex numbers)
 * output r
 */
#include "common.h"
#include "common_fpu.h"
#if  !XCHAL_HAVE_HIFI5_HP_VFPU && !XCHAL_HAVE_HIFI5S_HP_VFPU
DISCARD_FUN(void,vec_cplx_conjhf,(float16_t * restrict y,
		const float16_t * restrict x,
		int N))
#elif XCHAL_HAVE_HIFI5_HP_VFPU || XCHAL_HAVE_HIFI5S_HP_VFPU
void vec_cplx_conjhf(float16_t * restrict y,
				const float16_t * restrict x,
				int N)
{
   const xthalfx8 *pX;
   xthalfx8 *pY;
   int i;
   xthalfx4 x0,x1,y0,y1;
   if(N<0) return;
   NASSERT(x);
   NASSERT(y);
   NASSERT_ALIGN(x, 16);
   NASSERT_ALIGN(y, 16);
   NASSERT(N > 0 && N % 2 == 0);
   pX = (xthalfx8*)x;
   pY = (xthalfx8*)y;

   for(i=0;i<N>>2; i++) //when N>=4 complex elements
   {
	   AE_LHX4X2_IP(x0,x1,pX, sizeof(xthalfx8));
	   CONJC_HX4X2(y0,y1,x0,x1);
	   AE_SHX4X2_IP(y0,y1,pY, sizeof(xthalfx8));
   }
   if(N&2)//two complex numbers
   {
	   AE_LHX4IP(x0,(xthalfx4*)pX, sizeof(xthalfx4));
	   y0 = CONJC_H(x0);
	   AE_SHX4IP(y0,(xthalfx4*)pY, sizeof(xthalfx4));
   }
}
#endif
