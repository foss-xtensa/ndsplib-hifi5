/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */

#include "common.h"
#include "common_fpu.h"
#if  !XCHAL_HAVE_HIFI5_HP_VFPU && !XCHAL_HAVE_HIFI5S_HP_VFPU
DISCARD_FUN(void,vec_cplx_WeightedSum_hmhfV3,(	complex_float16* restrict cwsy, complex_float16* restrict x0, complex_float16* restrict x1,
		float16_t* restrict w,  int N ))
#elif XCHAL_HAVE_HIFI5_HP_VFPU || XCHAL_HAVE_HIFI5S_HP_VFPU
/*  vec_cplx_WeightedSum_hmhfV3 Vector
	CWS[i] = X0[i] + (W[i] o X1[i])
	where X1, X2 & W are complex-valued vectors, and o is the Hadamard product
*/
void vec_cplx_WeightedSum_hmhfV3(	complex_float16* restrict cwsy, complex_float16* restrict x0, complex_float16* restrict x1,
		float16_t* restrict w,  int N )
{
   const xthalfx8* restrict px0;
   const xthalfx8* restrict px1;
   const xthalfx8* restrict pw;
   xthalfx8* restrict pcwsy;
   int i;
   xthalfx4 x00, x01, x10, x11, w10, w11;
   xthalfx4 w10Conj_IR,w11Conj_IR;
   xthalfx4 z0RR,z1RR,z0RI,z1RI;
   xthalfx4 z0,z1;

   ae_int16x4 zRR_Int, zRI_Int;
   ae_int16x4 zRInt, zIInt;
   xthalfx4 z0R, z1R, z0I, z1I;
   //---------------------------SEL Index to flip Real and Imag after MUL
   static const ALIGN(16) int16_t selIdxP1[4] = { 0x0607, 0x0203, 0x0405, 0x0001 };
   ae_int16x4 selIdx1;
   selIdx1 = AE_L16X4_I((ae_int16x4*)&selIdxP1, 0);

   NASSERT(cwsy);
   NASSERT(x0);
   NASSERT(x1);
   NASSERT(w);
   NASSERT_ALIGN(cwsy, 16);
   NASSERT_ALIGN(x0, 16);
   NASSERT_ALIGN(x1, 16);
   NASSERT_ALIGN(w, 16);
   NASSERT(N > 0 && N % 4 == 0);
   if(N<0) return;

   px0 = (xthalfx8*)x0;
   px1 = (xthalfx8*)x1;
   pw =  (xthalfx8*)w;
   pcwsy = (xthalfx8*)cwsy;
   for(i=0; i<N>>2; i++)
   {
	   AE_LHX4X2_IP(x00, x01, px0,sizeof(xthalfx8));	// Load X0
	   AE_LHX4X2_IP(x10, x11, px1, sizeof(xthalfx8));	// Load X1
	   AE_LHX4X2_IP(w10, w11, pw, sizeof(xthalfx8));	// Load W1

	   MULJC_HX4X2(w10Conj_IR, w11Conj_IR, w10, w11);

	   MUL_HX4X2(z0RR, z1RR, x10, x11, w10, w11);
	   MUL_HX4X2(z0RI, z1RI, x10, x11, w10Conj_IR, w11Conj_IR);

	   zRR_Int = AE_MOVINT16X4_FROMXTHALFX4(z0RR);
	   zRI_Int = AE_MOVINT16X4_FROMXTHALFX4(z0RI);
	   AE_DSEL16X4(zRInt, zIInt, zRR_Int, zRI_Int, selIdx1); //arrange the elements for addition
	   z0R = AE_MOVXTHALFX4_FROMINT16X4(zRInt);
	   z0I = AE_MOVXTHALFX4_FROMINT16X4(zIInt);

	   zRR_Int = AE_MOVINT16X4_FROMXTHALFX4(z1RR);
	   zRI_Int = AE_MOVINT16X4_FROMXTHALFX4(z1RI);
	   AE_DSEL16X4(zRInt, zIInt, zRR_Int, zRI_Int, selIdx1);
	   z1R = AE_MOVXTHALFX4_FROMINT16X4(zRInt);
	   z1I = AE_MOVXTHALFX4_FROMINT16X4(zIInt);

	   ADD_HX4X2 (z0,z1,z0R,z1R,z0I,z1I);
	   ADD_HX4X2 (z0,z1,z0,z1,x00,x01);
	   AE_SHX4X2_IP(z0,z1,pcwsy, sizeof(xthalfx8));
   }
}
#endif
