/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */

#include "common.h"
#include <xtensa/sim.h>
#include "common_fpu.h"

#if  !XCHAL_HAVE_HIFI5_HP_VFPU
DISCARD_FUN(void,vec_cplx_Normhf,(complex_float16* cny, complex_float16* restrict x, int N))
#elif XCHAL_HAVE_HIFI5_HP_VFPU || XCHAL_HAVE_HIFI5S_HP_VFPU

/*  Complex Norm
	cplxnorm[n] = x[n] / euclidean_norm(x[n])
	where x = a + jb;
	Inputs  : X is complex-valued vector of length N
	Outputs : cny is a complex valued vector of length N
	N: N must be multiples of 2
*/

void vec_cplx_Normhf(complex_float16 * cny, complex_float16* restrict x, int N)
{
	int i;
	NASSERT(x);
	NASSERT(cny);
	NASSERT_ALIGN(x, 16);
	NASSERT_ALIGN(cny, 16);
	NASSERT(N > 0);
	xthalfx8 *px;
	xthalfx8 *pcny;
	xthalfx4 x0,x1,x0Sq,x1Sq, y0, y1;
	ae_int16x4 xR_Int, xI_Int;
	xthalfx4 xRSq, xISq;
	ae_int16x4 x0Sq_Int,x1Sq_Int;

	//---------------------------SEL Index to select Real in one register and Imag in another-----------------
	static const ALIGN(16) int16_t selIdxP1[4] = { 0x0706, 0x0504, 0x0302, 0x0100 };
	ae_int16x4 selIdx1;
	selIdx1 = AE_L16X4_I((ae_int16x4*)&selIdxP1, 0);
	static const ALIGN(16) int16_t selIdxP2[4] = { 0x0705, 0x0705, 0x0604, 0x0604 };
	ae_int16x4 selIdx2;
	selIdx2 = AE_L16X4_I((ae_int16x4*)&selIdxP2, 0);
	if(N<0) return;
	px  = (xthalfx8*)x;
	pcny = (xthalfx8*)cny;

	for(i=0; i< (N>>2); i++)
	{
		AE_LHX4X2_IP(x0,x1,px,sizeof(xthalfx8));
		MUL_HX4X2(x0Sq,x1Sq,x0,x1,x0,x1); //real^2, Imag^2

		x0Sq_Int = AE_MOVINT16X4_FROMXTHALFX4(x0Sq);
		x1Sq_Int = AE_MOVINT16X4_FROMXTHALFX4(x1Sq);
		AE_DSEL16X4(xR_Int, xI_Int, x0Sq_Int, x1Sq_Int, selIdx1);
		xRSq = AE_MOVXTHALFX4_FROMINT16X4(xR_Int); //xRSq
		xISq = AE_MOVXTHALFX4_FROMINT16X4(xI_Int); //xISq
		xRSq = ADD_HX4(xRSq,xISq); //real^2+imag^2

		x0Sq = SQRT_HX4(xRSq); //sqrt(real^2+imag^2)

		x0Sq = DIV_HX4(CONST_HX4(1),x0Sq); //1/(magnitude))

		x0Sq_Int = AE_MOVINT16X4_FROMXTHALFX4(x0Sq);
		AE_DSEL16X4(x0Sq_Int, x1Sq_Int, x0Sq_Int, x0Sq_Int, selIdx2); //make copies for division
		x0Sq = AE_MOVXTHALFX4_FROMINT16X4(x0Sq_Int);
		x1Sq = AE_MOVXTHALFX4_FROMINT16X4(x1Sq_Int);

		MUL_HX4X2(y0,y1,x0,x1,x0Sq,x1Sq); //multiply by inverse
		AE_SHX4X2_IP(y0,y1,pcny,sizeof(xthalfx8));
	}

	if(N&2) //for last 2 complex numbers
	{
		xthalfx4 x0T;
		AE_LHX4IP(x0,castxcc(xthalfx4,px),sizeof(xthalfx4));
		x0Sq = MUL_HX4(x0,x0); //real^2, Imag^2
		#if(XCHAL_HW_VERSION>=290030)
				x0T = AE_SELHX4I(x0Sq,x0Sq,12); //reverse the real and imag part for additon
		#else
				x0T = AE_SELH_2301(x0Sq,x0Sq); //reverse the real and imag part for additon
		#endif
		x0T = ADD_HX4(x0Sq,x0T); //real^2+imag^2
		x0T = SQRT_HX4(x0T); //sqrt(real^2+imag^2)
		y0 = DIV_HX4(x0,x0T); //x0/(magnitude))
		AE_SHX4IP(y0,castxcc(xthalfx4,pcny),sizeof(xthalfx4));

	}
}
#endif
