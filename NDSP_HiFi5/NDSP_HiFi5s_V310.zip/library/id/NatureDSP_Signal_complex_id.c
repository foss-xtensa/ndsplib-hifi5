/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
/*
 * NatureDSP_Signal Library API
 * Complex Math Functions
 * Annotations
 */

#include "NatureDSP_types.h"
#include "NatureDSP_Signal_complex.h"
#include "common.h"


ANNOTATE_FUN(vec_complex2mag,    	"Vector Complex Magnitude (floating point data)            ");
ANNOTATE_FUN(vec_complex2invmag, 	"Vector Reciprocal Complex Magnitude (floating point data) ");
ANNOTATE_FUN(cxfir_Freq_acorrf,     "complex Freq. domain autocorrelation(Hadamard product) (floating point data)");
ANNOTATE_FUN(cxfir_FreqXcorrf,    	"complex Freq. domain crosscorrelation(Hadamard product) floating point data)");
ANNOTATE_FUN(vec_cplx_Coherencef, 	"Vector complex coherence  (floating point data)");
ANNOTATE_FUN(vec_cplx_Conjf, 		"Vector complex conjugate  (floating point data)");
ANNOTATE_FUN(vec_cplx_Normf, 		"Vector complex norm  (floating point data)");
ANNOTATE_FUN(vec_cplx_SqNormf, 		"Vector complex squared norm  (floating point data)");
ANNOTATE_FUN(scl_complex2mag,    	"Scalar Complex Magnitude (floating point data)            ");
ANNOTATE_FUN(scl_complex2invmag, 	"Scalar Reciprocal Complex Magnitude (floating point data) ");
ANNOTATE_FUN(vec_cplx_WeightedSumfV1,"vector complex weighted sumV1: complex inputs x0, x1, complex weights w0, w1 (floating point data) ");
ANNOTATE_FUN(vec_cplx_WeightedSumfV2,"vector complex weighted sumV2: complex inputs x0, x1, real weight w (floating point data) ");
ANNOTATE_FUN(vec_cplx_WeightedSumfV3,"vector complex weighted sumV3: complex inputs x0, x1, complex weight w (floating point data) ");
ANNOTATE_FUN(vec_cplx_WeightedSum_hmfV1,"vector complex weighted sum hm V1: complex inputs x0, x1, complex weights w0, w1 (hadamard product of floating point data) ");
ANNOTATE_FUN(vec_cplx_WeightedSum_hmfV2,"vector complex weighted sum hm V2: complex inputs x0, x1, real weight w (hadamard product of floating point data) ");
ANNOTATE_FUN(vec_cplx_WeightedSum_hmfV3,"vector complex weighted sum hm V3: complex inputs x0, x1, complex weight w (hadamard product of floating point data) ");
ANNOTATE_FUN(cxfir_Freq_acorrhf, 	 "Vector complex Freq. domain autocorrelation(Hadamard product) (half precision floating point data)");
ANNOTATE_FUN(cxfir_FreqXcorrhf, 	 "Vector complex Freq. domain crosscorrelation(Hadamard product) (half precision floating point data)");
ANNOTATE_FUN(vec_cplx_Coherencehf, 	 "Vector complex coherence  (half precision floating point data)");
ANNOTATE_FUN(vec_cplx_conjhf, 		 "Vector complex conjugate  (half precision floating point data)");
ANNOTATE_FUN(vec_cplx_Normhf, 		 "Vector complex norm  (half precision floating point data)");
ANNOTATE_FUN(vec_cplx_SqNormhf, 	 "Vector complex squared norm  (half precision floating point data)");
ANNOTATE_FUN(vec_cplx_WeightedSumhfV1,"vector complex weighted sumV1: complex inputs x0, x1, complex weights w0, w1 (half precision floating point data) ");
ANNOTATE_FUN(vec_cplx_WeightedSumhfV2,"vector complex weighted sumV2: complex inputs x0, x1, real weight w (half precision floating point data) ");
ANNOTATE_FUN(vec_cplx_WeightedSumhfV3,"vector complex weighted sumV3: complex inputs x0, x1, complex weight w (half precision floating point data) ");
ANNOTATE_FUN(vec_cplx_WeightedSum_hmhfV1,"vector complex weighted sum hm V1: complex inputs x0, x1, complex weights w0, w1 (hadamard product of half precision floating point data) ");
ANNOTATE_FUN(vec_cplx_WeightedSum_hmhfV2,"vector complex weighted sum hm V2: complex inputs x0, x1, real weight w (hadamard product of half precision floating point data) ");
ANNOTATE_FUN(vec_cplx_WeightedSum_hmhfV3,"vector complex weighted sum hm V3: complex inputs x0, x1, complex weight w (hadamard product of half precision floating point data) ");
