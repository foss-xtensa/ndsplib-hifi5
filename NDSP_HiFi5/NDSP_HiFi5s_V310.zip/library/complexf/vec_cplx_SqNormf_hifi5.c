/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */

#include "common.h"
#include "common_fpu.h"
#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_SqNormf,(float32_t* csny, complex_float* restrict x, int N))
#elif HAVE_VFPU
/*  Complex Squared Norm :  Vector
	CSQN[i] = (X.real_sq[i] + X.img_sq[i])
	Inputs  : X is complex-valued vector of length N
	Outputs : csny is a real valued vector of length N
*/
void vec_cplx_SqNormf(float32_t* csny, complex_float* restrict x, int N)
{
   const xtfloatx4 *px;
   	   	 xtfloatx2 *pcsny;
   int i;
   xtfloatx2 x10, x11;
   xtfloatx2 r0, r1, r;
   if(N<0) return;
   px  = (xtfloatx4*)x;
   pcsny = (xtfloatx2*)csny;
   for(i=0; i< (N>>1); i++)
   {
	   AE_LSX2X2_IP(x10, x11, px,  sizeof(xtfloatx4));	// Load X
	   MUL_SX2X2(r0, r1, x10, x11, x10, x11);
	   r0 = ADD_HL_LH_S(r0, r0);
	   r1 = ADD_HL_LH_S(r1, r1);
	   r = AE_SEL32_HH_SX2(r0, r1);
	   AE_SSX2IP(r,pcsny, sizeof(xtfloatx2));
   }
}
#endif
