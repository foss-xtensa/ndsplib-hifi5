/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */

#include "common.h"
#include "common_fpu.h"
#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void, vec_cplx_WeightedSumfV2,(	complex_float* cwsy, complex_float* restrict x0, complex_float* restrict x1,
		float32_t* restrict w, int N ))
#elif HAVE_VFPU
/*  complexWeightedSum_V2 Vector
	CWS[i] = (W[i] * X1[i]) + ((1-W[i]) * X2[i])
	where X1 & X2 are complex-valued vectors, W is a real-valued vector,  and *  is  multiplication
*/
void vec_cplx_WeightedSumfV2(	complex_float* cwsy, complex_float* restrict x0, complex_float* restrict x1,
									float32_t* restrict w, int N )
{
	const xtfloatx4 *px1, *px2;
	const xtfloatx2 *pw;
	xtfloatx4 *pcwsy;
	int i;
	xtfloatx2 x10, x11, x20, x21, wtmp, w10, w11, _1;
	xtfloatx2 r1t0, r1t1, r2t0, r2t1;
	xtfloatx2 r0, r1;

	NASSERT(cwsy);
	NASSERT(x0);
	NASSERT(x1);
	NASSERT(w);
	NASSERT_ALIGN(cwsy, 16);
	NASSERT_ALIGN(x0, 16);
	NASSERT_ALIGN(x1, 16);
	NASSERT_ALIGN(w, 16);
	NASSERT(N > 0 && N % 2 == 0);

	if(N<0) return;

	px1 = (xtfloatx4*)x0;
	px2 = (xtfloatx4*)x1;
	pw =  (xtfloatx2*)w;
	pcwsy = (xtfloatx4*)cwsy;
	_1= CONST_SX2(1);
	for(i=0; i<N>>1; i++)
	{
		AE_LSX2X2_IP(x10, x11, px1, sizeof(xtfloatx4));	// Load X1
		AE_LSX2X2_IP(x20, x21, px2, sizeof(xtfloatx4));	// Load X2
		AE_LSX2IP(wtmp, pw, sizeof(xtfloatx2));			// Load wtmpH, wtmpL
		w10 = AE_SEL32_HH_SX2(wtmp, wtmp);
		w11 = AE_SEL32_LL_SX2(wtmp, wtmp);
		MUL_SX2X2(r1t0, r1t1, w10, w11, x10, x11);
		SUB_SX2X2(w10,w11,_1,_1,w10,w11);
		MUL_SX2X2(r2t0, r2t1, w10, w11, x20, x21);
		ADD_SX2X2(r0,r1,r1t0,r1t1,r2t0,r2t1);
		AE_SSX2X2_IP(r0,r1,pcwsy, sizeof(xtfloatx4));
	}
}
#endif
