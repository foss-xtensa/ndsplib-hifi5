/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */

#include "common.h"
#include "common_fpu.h"

#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_Coherencef,(complex_float* ccohy, complex_float* restrict x0,
        complex_float* restrict x1, int N))
#elif HAVE_VFPU

void vec_cplx_Coherencef(complex_float* ccohy, complex_float* restrict x0,
		                      complex_float* restrict x1, int N)
{
   const xtfloatx4 *px0, *px1;
   	   	 xtfloatx4 *pccohy;
   int i;
   xtfloatx2 x00, x01, x10, x11;
   xtfloatx2 x00cj, x01cj, x10cj, x11cj;
   xtfloatx2 rNr0, rDr00, rDr01, rNr1, rDr10, rDr11;
   xtfloatx2 r0, r1;
   if(N<0) return;
   px0 = (xtfloatx4*)x0;
   px1 = (xtfloatx4*)x1;
   pccohy = (xtfloatx4*)ccohy;
   for(i=0; i<N>>1; i++)
   {
	   AE_LSX2X2_IP(x00, x01, px0, sizeof(xtfloatx4));	// Load X1
	   AE_LSX2X2_IP(x10, x11, px1, sizeof(xtfloatx4));	// Load X2
	   CONJC_SX2X2(x00cj, x01cj, x00, x01);
	   CONJC_SX2X2(x10cj, x11cj, x10, x11);
	   MULC_SX2(rNr0, rNr1, x00, x01, x10cj, x11cj);
	   MULC_SX2(rDr00, rDr01, x00, x01, x00cj, x01cj);
	   MULC_SX2(rDr10, rDr11, x10, x11, x10cj, x11cj);
	   MUL_SX2X2(r0, r1, rDr00, rDr01, rDr10, rDr11);
	   r0 = SQRT_SX2(r0);
	   r1 = SQRT_SX2(r1);
	   r0 = AE_SEL32_HH_SX2(r0,r0);
	   r1 = AE_SEL32_HH_SX2(r1,r1);
	   r0 = RECIP_SX2(r0);
	   r1 = RECIP_SX2(r1);
	   MUL_SX2X2(r0, r1, rNr0, rNr1, r0, r1);
	   AE_SSX2X2_IP(r0, r1, pccohy, sizeof(xtfloatx4));
   }
}
#endif
