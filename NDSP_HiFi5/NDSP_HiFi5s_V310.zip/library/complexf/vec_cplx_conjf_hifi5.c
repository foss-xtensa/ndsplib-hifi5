/* ------------------------------------------------------------------------ */
/* Copyright (c) 2020-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 5s DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */

/*
 * Vector Operations
 * vector complex conjugate operation for floating point data
 *
 */
/* input x complex xtfloat
 * output r complex xtfloat
 * N should be multiple of 2
 */
#include "common.h"
#include "common_fpu.h"

#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_Conjf,(complex_float * restrict r,
		const complex_float * restrict x,
		int N))
#elif HAVE_VFPU

void vec_cplx_Conjf(complex_float * restrict r,
				const complex_float * restrict x,
				int N)
{
	const xtfloatx4 *pX;
   		  xtfloatx4 *pR;
   	int i;
   	xtfloatx2 x0,x1,r0,r1;

	NASSERT(r);
	NASSERT(x);
	NASSERT_ALIGN(r, 16);
	NASSERT_ALIGN(x, 16);
	NASSERT(N > 0 && N % 2 == 0);
	if(N<0) return;

	pX = (xtfloatx4*)x;
	pR = (xtfloatx4*)r;
	for(i=0;i<N>>1; i++)
	{
		AE_LSX2X2_IP(x0,x1,pX, sizeof(xtfloatx4));
		CONJC_SX2X2(r0,r1,x0,x1);
		AE_SSX2X2_IP(r0,r1,pR, sizeof(xtfloatx4));
	}
    if(N&1)
    {
 	   AE_LSX2IP(x0, castxcc(xtfloatx2,pX), sizeof(xtfloatx2));
 	   r0 = CONJC_S(x0);
 	   AE_SSX2IP(r0,castxcc(xtfloatx2,pR), sizeof(xtfloatx2));
    }
}
#endif
