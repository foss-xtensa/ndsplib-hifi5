/*
 * Copyright (c) 2024 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

#include "common.h"
#include <xtensa/sim.h>
#include "common_fpu.h"

#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_Normhf,(complex_float16* cny, complex_float16* restrict x, int N))
#elif HAVE_VFPU

/*  Complex Norm
	cplxnorm[n] = x[n] / euclidean_norm(x[n])
	where x = a + jb;
	Inputs  : X is complex-valued vector of length N
	Outputs : cny is a complex valued vector of length N
*/

void vec_cplx_Normhf(complex_float16 * cny, complex_float16* restrict x, int N)
{
       int i;
       NASSERT(x);
       NASSERT(cny);
       NASSERT_ALIGN(x, 16);
       NASSERT_ALIGN(cny, 16);
       NASSERT(N > 0);
       xthalfx4 *px;
       xthalfx4 *pcny;
       xthalfx4 x0,x0Sq, x0T, y0;
       px  = (xthalfx4*)x;
       pcny = (xthalfx4*)cny;
       for(i=0; i< (N>>1); i++)
       {
           AE_LHX4IP(x0,px,sizeof(xthalfx4));
           x0Sq = MUL_HX4(x0,x0); //real^2, Imag^2
           #if(XCHAL_HW_VERSION>=290030)
              x0T = AE_SELHX4I(x0Sq,x0Sq,12); //reverse the real and imag part for additon
           #else
              x0T = AE_SELH_2301(x0Sq,x0Sq); //reverse the real and imag part for additon
           #endif
           x0T = ADD_HX4(x0Sq,x0T); //real^2+imag^2
           x0T = SQRT_HX4(x0T); //sqrt(real^2+imag^2)
           y0 = DIV_HX4(x0,x0T); //x0/(magnitude))
           AE_SHX4IP(y0,pcny,sizeof(xthalfx4));
       }
}
#endif
