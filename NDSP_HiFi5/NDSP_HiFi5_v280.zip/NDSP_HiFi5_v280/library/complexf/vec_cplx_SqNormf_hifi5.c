/*
 * Copyright (c) 2024 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

#include "common.h"
#include "common_fpu.h"
#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_SqNormf,(float32_t* csny, complex_float* restrict x, int N))
#elif HAVE_VFPU
/*  Complex Squared Norm :  Vector
	CSQN[i] = (X.real_sq[i] + X.img_sq[i])
	Inputs  : X is complex-valued vector of length N
	Outputs : csny is a real valued vector of length N
*/
void vec_cplx_SqNormf(float32_t* csny, complex_float* restrict x, int N)
{
   const xtfloatx4 *px;
   	   	 xtfloatx2 *pcsny;
   int i;
   xtfloatx2 x10, x11;
   xtfloatx2 r0, r1, r;
   if(N<0) return;
   px  = (xtfloatx4*)x;
   pcsny = (xtfloatx2*)csny;
   for(i=0; i< (N>>1); i++)
   {
	   AE_LSX2X2_IP(x10, x11, px,  sizeof(xtfloatx4));	// Load X
	   MUL_SX2X2(r0, r1, x10, x11, x10, x11);
	   r0 = ADD_HL_LH_S(r0, r0);
	   r1 = ADD_HL_LH_S(r1, r1);
	   r = AE_SEL32_HH_SX2(r0, r1);
	   AE_SSX2IP(r,pcsny, sizeof(xtfloatx2));
   }
}
#endif
