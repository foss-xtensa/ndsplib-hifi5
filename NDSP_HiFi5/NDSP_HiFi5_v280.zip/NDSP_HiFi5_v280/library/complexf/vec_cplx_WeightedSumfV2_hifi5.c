/*
 * Copyright (c) 2024 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

#include "common.h"
#include "common_fpu.h"
#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void, vec_cplx_WeightedSumfV2,(	complex_float* cwsy, complex_float* restrict x0, complex_float* restrict x1,
		float32_t* restrict w, int N ))
#elif HAVE_VFPU
/*  complexWeightedSum_V2 Vector
	CWS[i] = (W[i] o X1[i]) + ((1-W[i]) o X2[i])
	where X1 & X2 are complex-valued vectors, W is a real-valued vector,  and o  is the Hadamard product
*/
void vec_cplx_WeightedSumfV2(	complex_float* cwsy, complex_float* restrict x0, complex_float* restrict x1,
									float32_t* restrict w, int N )
{
   const xtfloatx4 *px1, *px2;
   const xtfloatx2 *pw;
   	   	 xtfloatx4 *pcwsy;
   int i;
   xtfloatx2 x10, x11, x20, x21, wtmp, w10, w11, w20, w21, tmp1,tmp2;
   xtfloatx2 r1t0, r1t1, r2t0, r2t1;
   xtfloatx2 r0, r1;

   NASSERT(cwsy);
   NASSERT(x0);
   NASSERT(x1);
   NASSERT(w);
   NASSERT_ALIGN(cwsy, 16);
   NASSERT_ALIGN(x0, 16);
   NASSERT_ALIGN(x1, 16);
   NASSERT_ALIGN(w, 16);
   NASSERT(N > 0 && N % 2 == 0);

   if(N<0) return;

   px1 = (xtfloatx4*)x0;
   px2 = (xtfloatx4*)x1;
   pw =  (xtfloatx2*)w;
   pcwsy = (xtfloatx4*)cwsy;
   CONST_SX2X2(tmp1, tmp2, 1);
   for(i=0; i<N>>1; i++)
   {
	   AE_LSX2X2_IP(x10, x11, px1, sizeof(xtfloatx4));	// Load X1
	   AE_LSX2X2_IP(x20, x21, px2, sizeof(xtfloatx4));	// Load X2
	   AE_LSX2IP(wtmp, pw, sizeof(xtfloatx2));			// Load wtmpH, wtmpL
	   w10 = AE_SEL32_HH_SX2(wtmp, wtmp);
	   w11 = AE_SEL32_LL_SX2(wtmp, wtmp);
	   MUL_SX2X2(r1t0, r1t1, w10, w11, x10, x11);
	   w20 = SUB_SX2(tmp1, w10);
	   w21 = SUB_SX2(tmp2, w11);
	   MUL_SX2X2(r2t0, r2t1, w20, w21, x20, x21);
	   ADD_SX2X2(r0,r1,r1t0,r1t1,r2t0,r2t1);
	   AE_SSX2X2_IP(r0,r1,pcwsy, sizeof(xtfloatx4));
   }
}
#endif
