/*
 * Copyright (c) 2024 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */
/*  Complex Norm
	cplxnorm[n] = x[n] / euclidean_norm(x[n])
	where x = a + jb;
	Inputs  : X is complex-valued vector of length N
	Outputs : cny is a complex valued vector of length N
	Not tested for input special numbers (output can be special numbers)
	xreal/sqrt(xreal^2+ximag^2), ximag/sqrt(xreal^2+ximag^2)
*/
#include "common.h"
#include "common_fpu.h"

#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_Normf,(complex_float* cny, complex_float* restrict x, int N))
#elif HAVE_VFPU

#define FastButLessAccurate 0
void vec_cplx_Normf(complex_float* cny, complex_float* restrict x, int N)
{
	   const xtfloatx4 *px;
	   	   	 xtfloatx4 *pcny;
	   int i;

	   xtfloatx2 x10, x11;
	   xtfloatx2 rt0, rt1;
	   xtfloatx2 r0, r1;
	   if(N<0) return;
	   px  = (xtfloatx4*)x;
	   pcny = (xtfloatx4*)cny;
	   for(i=0; i< (N>>1); i++)
	   {
	   	   AE_LSX2X2_IP(x10, x11, px,  sizeof(xtfloatx4));	// Load X
	   	   MUL_SX2X2(rt0, rt1, x10, x11, x10, x11); //
		   rt0 = ADD_HL_LH_S(rt0, rt0);
		   rt1 = ADD_HL_LH_S(rt1, rt1);
		   rt0 = SQRT_SX2(rt0);
		   rt1 = SQRT_SX2(rt1);
#if FastButLessAccurate
		   //-------------reciprocal gives less accurate results------------
//		   rt0 = RECIP_SX2(rt0);
//		   rt1 = RECIP_SX2(rt1);
//		   MUL_SX2X2(r0, r1, x10, x11, rt0, rt1);
#else
		   //-------------divide gives better results but is slower------------
		   r0 = DIV_SX2(x10,rt0);
		   r1 = DIV_SX2(x11,rt1);
#endif
		   //------------------------------------------------------------------
		   AE_SSX2X2_IP(r0, r1, pcny, sizeof(xtfloatx4));
	   }
}
#endif
