/*
 * Copyright (c) 2024 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

/* This is time domain auto correlation
 * which is equivalent to frequency domain multiplication with complex conj. X.X*
 * Therefore Eventhough name is acorr, this is multiplication with conj.
 * x: inputs both must be of same length, aligned and complex
 * r: output (complex)
 * N: input and output length is same
 *
 */
#include "common.h"
#include "common_fpu.h"

#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,cxfir_Freq_acorrhf,( complex_float * restrict r,
		const complex_float * restrict x,
		int N ))
#elif HAVE_VFPU

void cxfir_Freq_acorrf( complex_float * restrict r,
						const complex_float * restrict x,
						int N )
{
	const xtfloatx4 *  pX;
		  xtfloatx4 * restrict pR;
		  xtfloatx2 x0, x1,  z0, z1;
	int i;

	NASSERT(r);
	NASSERT(x);
	NASSERT_ALIGN(r, 16);
	NASSERT_ALIGN(x, 16);
	NASSERT(N > 0 && N % 4 == 0);

	pX = (const xtfloatx4 *)x;
	pR = (xtfloatx4 *)r;
	for(i=0;i<(N>>1);i++)
	{
		AE_LSX2X2_IP(x0, x1, pX, sizeof(xtfloatx4));
	    MULCCONJ_SX2(z0,z1,x0,x1,x0,x1);
	    AE_SSX2X2_IP(z0, z1, pR, sizeof(xtfloatx4));
	}
}
#endif
