/*
 * Copyright (c) 2024 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

/*
 * Vector Operations
 * vector complex conjugate operation for floating point data
 *
 */
/* input x complex xtfloat
 * output r complex xtfloat
 * N should be multiple of 2
 */
#include "common.h"
#include "common_fpu.h"

#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_Conjf,(complex_float * restrict r,
		const complex_float * restrict x,
		int N))
#elif HAVE_VFPU

void vec_cplx_Conjf(complex_float * restrict r,
				const complex_float * restrict x,
				int N)
{
	const xtfloatx4 *pX;
   		  xtfloatx4 *pR;
   	int i;
   	xtfloatx2 x0,x1,r0,r1;

	NASSERT(r);
	NASSERT(x);
	NASSERT_ALIGN(r, 16);
	NASSERT_ALIGN(x, 16);
	NASSERT(N > 0 && N % 2 == 0);
	if(N<0) return;

	pX = (xtfloatx4*)x;
	pR = (xtfloatx4*)r;
	for(i=0;i<N>>1; i++)
	{
		AE_LSX2X2_IP(x0,x1,pX, sizeof(xtfloatx4));
		CONJC_SX2X2(r0,r1,x0,x1);
		AE_SSX2X2_IP(r0,r1,pR, sizeof(xtfloatx4));
	}
    if(N&1)
    {
 	   AE_LSX2IP(x0, castxcc(xtfloatx2,pX), sizeof(xtfloatx2));
 	   r0 = CONJC_S(x0);
 	   AE_SSX2IP(r0,castxcc(xtfloatx2,pR), sizeof(xtfloatx2));
    }
}
#endif
