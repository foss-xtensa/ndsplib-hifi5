/*
 * Copyright (c) 2024 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

#include "common.h"
#include "common_fpu.h"
#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_WeightedSumhfV2,(	complex_float16* cwsy, complex_float16* restrict x0, complex_float16* restrict x1,
		float16_t* restrict w, int N ))
#elif HAVE_VFPU
/*  complexWeightedSumhfV2 Vector
	CWS[i] = (W[i] o X1[i]) + ((1-W[i]) o X2[i])
	where X1 & X2 are complex-valued vectors, W is a real-valued vector,  and o  is the Hadamard product
*/
void vec_cplx_WeightedSumhfV2(	complex_float16* cwsy, complex_float16* restrict x0, complex_float16* restrict x1,
		float16_t* restrict w, int N )
{
   const xthalfx8 *px0, *px1;
   const xthalfx4 *pw;
   xthalfx8 *pcwsy;
   int i;
   xthalfx4 x00, x01, x10, x11, wtmp, w00, w11, const_1,_1Mw00, _1Mw11;
   xthalfx4 r0, r1;

   NASSERT(cwsy);
   NASSERT(x0);
   NASSERT(x1);
   NASSERT(w);
   NASSERT_ALIGN(cwsy, 16);
   NASSERT_ALIGN(x0, 16);
   NASSERT_ALIGN(x1, 16);
   NASSERT_ALIGN(w, 16);
   NASSERT(N > 0 && N % 8 == 0);

   if(N<0) return;

   px0 = (xthalfx8*)x0;
   px1 = (xthalfx8*)x1;
   pw =  (xthalfx4*)w;
   pcwsy = (xthalfx8*)cwsy;
   const_1 = CONST_HX4(1);
   for(i=0; i<N>>2; i++)
   {
	   AE_LHX4X2_IP(x00, x01, px0, sizeof(xthalfx8));	// Load X0
	   AE_LHX4X2_IP(x10, x11, px1, sizeof(xthalfx8));	// Load X1

	   AE_LHX4IP(wtmp, pw, sizeof(xthalfx4));			// Load wtmpH, wtmpL

	   w00	 	= AE_SELH_7362(wtmp, wtmp); //w0w0w1w1
	   w11 	  	= AE_SELH_5140(wtmp, wtmp); //w2w2w3w3

	   SUB_HX4X2(_1Mw00,_1Mw11,const_1,const_1,w00,w11);
	   MUL_HX4X2  (r0, r1, x00, x01, w00,w11);
	   MADD_HX4X2 (r0, r1, x10, x11, _1Mw00,_1Mw11);
	   AE_SHX4X2_IP(r0,r1,pcwsy, sizeof(xthalfx8));
   }
}
#endif
