/*
 * Copyright (c) 2024 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

#include "common.h"
#include <xtensa/sim.h>
#include "common_fpu.h"

#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_SqNormhf,(float16_t* csny, complex_float16* restrict x, int N))
#elif HAVE_VFPU
/*  Complex Squared Norm :  Vector
	CSQN[i] = (X.real_sq[i] + X.img_sq[i])
	Inputs  : X is complex-valued vector of length N
	Outputs : csny is a real valued vector of length N
*/

#if(XCHAL_HW_VERSION>=290030)
void vec_cplx_SqNormhf(float16_t* csny, complex_float16* restrict x, int N)
{
	xthalf *px;
	xthalf *pcsny;
	NASSERT(x);
	NASSERT(csny);
	NASSERT_ALIGN(x, 16);
	NASSERT_ALIGN(csny, 16);
	NASSERT(N > 0);
	int i;
	px  = (xthalf*)x;
	pcsny = (xthalf*)csny;
	int Idx=0;
	for(i=0; i< (N<<1); i+=2)
	{
		pcsny[Idx] = (px[i]*px[i])+(px[i+1]*px[i+1]);
		Idx++;
	}
}
#else
void vec_cplx_SqNormhf(float16_t* csny, complex_float16* restrict x, int N)
{
	const xthalfx8 *px;
	xthalfx4 *pcsny;
	int i;
	xthalfx4 x10, x11;
	xthalfx4 r0, r1;
	xthalfx4 r0IR, r1IR;
	if(N<0) return;
	px  = (xthalfx8*)x;
	pcsny = (xthalfx4*)csny;
	for(i=0; i< (N>>2); i++) //N multiples of 4
	{
		AE_LHX4X2_IP(x10, x11, px,  sizeof(xthalfx8));	// Load X
		MUL_HX4X2(r0, r1, x10, x11, x10, x11);
		r0IR = AE_SELH_2301(r0, r0);
		r1IR = AE_SELH_2301(r1, r1);
		ADD_HX4X2(r0,r1,r0,r1, r0IR,r1IR);
		r0 = AE_SELH_7520(r0, r1);
		AE_SHX4IP(r0,pcsny, sizeof(xthalfx4));
	}
	for(i=0;i<(N&3);i++)
	{
		xthalf x0real, x0img, r0real, r0img;
		AE_LHIP(x0real, castxcc(xthalf,px),  sizeof(xthalf));	// Load Xreal
		AE_LHIP(x0img, castxcc(xthalf,px),  sizeof(xthalf));	// Load Ximaginary
		r0real = MUL_H(x0real, x0real);
		r0img  = MUL_H(x0img, x0img);
		r0real = ADD_H(r0real,r0img);
		AE_SHIP(r0real, castxcc(xthalf,pcsny), sizeof(xthalf));	// store

	}
}
#endif
#endif
