/*
 * Copyright (c) 2024 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

#include "common.h"
#include "common_fpu.h"
#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,vec_cplx_WeightedSumhfV3,(	complex_float16* restrict cwsy, complex_float16* restrict x0, complex_float16* restrict x1,
		float16_t* restrict w,  int N ))
#elif HAVE_VFPU
/*  complexWeightedSumhfV3 Vector
	CWS[i] = X0[i] + (W[i] o X1[i])
	where X1, X2 & W are complex-valued vectors, and o is the Hadamard product
*/
void vec_cplx_WeightedSumhfV3(	complex_float16* restrict cwsy, complex_float16* restrict x0, complex_float16* restrict x1,
		float16_t* restrict w,  int N )
{
   const xthalfx8* restrict px0;
   const xthalfx8* restrict px1;
   const xthalfx8* restrict pw;
   xthalfx8* restrict pcwsy;
   int i;
   xthalfx4 x00, x01, x10, x11, w10, w11;
   xthalfx4 w10Conj, w11Conj, w10LH, w11LH;
   xthalfx4 r00rLH, r01rLH, r00iLH, r01iLH;
   xthalfx4 r10, r11, r00r, r01r, r00i, r01i, r0r, r1r, r0i, r1i, r00ri,r01ri;
   xthalfx4 r0, r1;

   NASSERT(cwsy);
   NASSERT(x0);
   NASSERT(x1);
   NASSERT(w);
   NASSERT_ALIGN(cwsy, 16);
   NASSERT_ALIGN(x0, 16);
   NASSERT_ALIGN(x1, 16);
   NASSERT_ALIGN(w, 16);
   NASSERT(N > 0 && N % 4 == 0);
   if(N<0) return;

   px0 = (xthalfx8*)x0;
   px1 = (xthalfx8*)x1;
   pw =  (xthalfx8*)w;
   pcwsy = (xthalfx8*)cwsy;
   for(i=0; i<N>>2; i++)
   {
	   AE_LHX4X2_IP(x00,x01,px0,sizeof(xthalfx8));	// Load X0


	   AE_LHX4X2_IP(x10, x11, px1, sizeof(xthalfx8));	// Load X1
	   AE_LHX4X2_IP(w10, w11, pw, sizeof(xthalfx8));	// Load W1
	   CONJC_HX4X2(w10Conj,  w11Conj, w10, w11); //wre, -wim

	   w10LH = AE_SELH_2301(w10, w10); //flip the real and imag parts of wt
	   w11LH = AE_SELH_2301(w11, w11); //flip the real and imag parts of wt

	   MUL_HX4X2(r00r, r01r, x10, x11, w10Conj, w11Conj); //[x1r*w1r  x1i*(-w1i)]
	   MUL_HX4X2(r00i, r01i, x10, x11, w10LH, w11LH);	  // [x1r*w1i    x1i*w1r]

	   r00rLH = AE_SELH_2301(r00r, r00r); //real data, flip for addition [x1i*(-w1i) x1r*w1r]
	   r01rLH = AE_SELH_2301(r01r, r01r); //real data, flip for addition

	   ADD_HX4X2(r0r, r1r, r00rLH, r01rLH,r00r, r01r); // [x1r*w1r  x1i*(-w1i)] + [x1i*(-w1i) x1r*w1r]

	   //r0, r1, higher 2 elements will be same, can select any one
	   //similarly lower 2 elements will be same can select any one

	   r00iLH = AE_SELH_2301(r00i, r00i); //imag data flip for addition  [ x1i*w1r x1r*w1i]
	   r01iLH = AE_SELH_2301(r01i, r01i); //imag data flip for addition

	   ADD_HX4X2(r0i, r1i, r00iLH, r01iLH,r00i, r01i);   // [x1r*w1i + x1i*w1r] +  [ x1i*w1r x1r*w1i]
	   //r2, r3, higher 2 elements will be same, can select any one
	   //similarly lower 2 elements will be same can select any one
	   r00ri = AE_SELH_7362(r0r,r0i); //Select real, imag (R0I0, R0I0)
	   r01ri = AE_SELH_5140(r0r,r0i); //Select real, imag (R1I1, R1I1)
	   r10   = AE_SELH_7610(r00ri,r01ri); //Select real, imag (R0I0, R1I1)

	   r00ri = AE_SELH_7362(r1r,r1i); //Select real, imag (R0I0, R0I0)
	   r01ri = AE_SELH_5140(r1r,r1i); //Select real, imag (R1I1, R1I1)
	   r11   = AE_SELH_7610(r00ri,r01ri); //Select real, imag (R0I0, R1I1)

	   ADD_HX4X2(r0,r1, x00, x01, r10, r11);

	   AE_SHX4X2_IP(r0,r1,pcwsy, sizeof(xthalfx8));	// Store result
   }
}
#endif
