/* ------------------------------------------------------------------------ */
/* Copyright (c) 2022 by Cadence Design Systems, Inc. ALL RIGHTS RESERVED.  */
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library                                                 */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (C) 2009-2022 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
/*
  NatureDSP Signal Processing Library. FIR part
    helper for correlation/convolution
    C code optimized for HiFi5
 */

/* This is time domain cross correlation
 * which is equivalent to frequency domain multiplication with complex conj.
 * Therefore Eventhough name is Xcorr, this is multiplication with conj.
 * x, y: inputs both must be of same length
 * r: output
 * input and output length is same
 * N must be equal to M
 */
#include "common.h"
#include "common_fpu.h"

#if !HAVE_VFPU && !HAVE_FPU
DISCARD_FUN(void,cxfir_FreqXcorrhf,(   complex_float16 * restrict r,
		const complex_float16 * restrict x,
		const complex_float16 * restrict y,
		int N))
#elif HAVE_VFPU

void cxfir_FreqXcorrhf(   complex_float16 * restrict r,
				const complex_float16 * restrict x,
				const complex_float16 * restrict y,
				int N)
{
	    const xthalfx8* restrict pX;
	    const xthalfx8* restrict pY;
	          xthalfx8 * restrict pR;
	    xthalfx4 x0, x1, y0, y1, z0, z1;
	    xthalfx4 y0Conj, y1Conj;
	    xthalfx4 y0Conj_IR,y1Conj_IR,z0Real,z1Real,z0Img,z1Img,z0_H,z0_L,z1_H,z1_L;

	    int i;
	    NASSERT(r);
	    NASSERT(x);
	    NASSERT(y);
	    NASSERT_ALIGN(r, 16);
	    NASSERT_ALIGN(x, 16);
	    NASSERT_ALIGN(y, 16);
	    NASSERT(N > 0 && N % 4 == 0);

	    pX = (const xthalfx8 *)x;
	    pY = (const xthalfx8 *)y;
	    pR = (xthalfx8 *)r;

	    for(i=0;i<(N>>2);i++) //works only when M is multiple of 4, 4 complex elements
	    {
	    	AE_LHX4X2_IP(x0, x1, pX, sizeof(xtfloatx4));
	    	AE_LHX4X2_IP(y0, y1, pY, sizeof(xtfloatx4));

	    	CONJC_HX4X2(y0Conj,y1Conj,y0,y1);

	    	y0Conj_IR = AE_SELH_2301(y0Conj,y0Conj);
	    	y1Conj_IR = AE_SELH_2301(y1Conj,y1Conj);

	    	MUL_HX4X2(z0Real, z1Real, x0, x1, y0, y1);
	    	MUL_HX4X2(z0Img, z1Img, x0, x1, y0Conj_IR, y1Conj_IR);

	    	z0_H = AE_SELH_7362(z0Real,z0Img);
	    	z0_L = AE_SELH_5140(z0Real,z0Img);

	    	z1_H = AE_SELH_7362(z1Real,z1Img);
	    	z1_L = AE_SELH_5140(z1Real,z1Img);

	    	z0Real = AE_SELH_7632(z0_H,z0_L);
	    	z0Img  = AE_SELH_5410(z0_H,z0_L);

	    	z1Real = AE_SELH_7632(z1_H,z1_L);
	    	z1Img  = AE_SELH_5410(z1_H,z1_L);

	    	ADD_HX4X2 (z0,z1,z0Real,z1Real,z0Img,z1Img);
	    	AE_SHX4X2_IP(z0,z1,pR, sizeof(xthalfx8));
	    }
}
#endif
